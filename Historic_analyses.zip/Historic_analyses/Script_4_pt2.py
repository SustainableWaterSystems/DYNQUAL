

import pandas as pd
import numpy as np 
from matplotlib import pyplot as plt
from numpy import hstack
import geopandas as gpd
import mapclassify
import netCDF4 as nc
import cartopy.crs as ccrs
from pylab import *
import xarray





for ii in ['11','12','13','14','15','16','17','18','19','20']:

  oxygen = np.load('/scratch/depfg/graha010/HYBRID_HISTORIC_RUN_JAN_9/M' + ii + '_do.npy')
  
  pb = nc.Dataset('/scratch/depfg/graha010/DYNQUAL_GLOBAL_OUTPUT_ONLINE/M' + ii + '/netcdf/oxygen_dailyTot_output.nc')
  time = pb['time'][:]
  
  lat = np.load('/scratch/depfg/graha010/HYBRID_HISTORIC_RUN_JAN_9/M' + ii + '_lat.npy')
  lon = np.load('/scratch/depfg/graha010/HYBRID_HISTORIC_RUN_JAN_9/M' + ii + '_lon.npy')

  data = xarray.DataArray(oxygen, coords=[('time', time), ('lat', lat), ('lon', lon)], name='Hybrid_DO')
  
  data.attrs['name'] = 'Dissolved Oxygen (DynQual_Random Forest)'
  data.attrs['units'] = 'mg/l'
  data.time.attrs['name'] = 'time'
  data.time.attrs['units'] = 'days since 1901-01-01'
  data.lat.attrs['name'] = 'latitude'
  data.lat.attrs['units'] = 'degrees_north'
  data.lon.attrs['name'] = 'longitude'
  data.lon.attrs['units'] = 'degrees_east'

  data.to_netcdf('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M' + ii + '_DO.nc')

  print(np.nanmin(np.nanmin(oxygen)))
  print(np.nanmax(np.nanmax(oxygen)))
  print(ii)


