

import pandas as pd 

data_2 = pd.read_csv('/scratch/depfg/graha010/Miscellaneous/Column_With_Climate.csv',sep=';')
data_2 = data_2.dropna()
data_2 = data_2[['Oxygen','climate']]
data_2['climate'] = data_2['climate'].str[0]
data_2['Oxygen'] = data_2['Oxygen'].str.replace(',','.').astype(float)

print(data_2)
data_2 = data_2.groupby(['climate'])['Oxygen'].mean()
print(data_2)

