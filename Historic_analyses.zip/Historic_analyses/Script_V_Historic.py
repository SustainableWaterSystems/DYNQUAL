
import pandas as pd
import numpy as np 
from matplotlib import pyplot as plt
from numpy import hstack
import geopandas as gpd
import mapclassify
import netCDF4 as nc
import cartopy.crs as ccrs
from pylab import *
from numpy import hstack





data_all = pd.read_csv('/scratch/depfg/graha010/Machine learning/x_test_Final_1.csv',sep=',')
data_all = data_all[['Station','Day','Lat','Lon','DO obs','oxygen']]
data_all = data_all.sort_values(['Station','Day','Lat','Lon'],ascending=[True,True,True,True])
data_all = data_all.reset_index(drop=True)




observed = data_all['DO obs']
simulated = data_all['oxygen']                  
difference = simulated - observed
difference_sqrd = difference.pow(2)
data_all['Sqrd difference'] = difference_sqrd



sqrd_difference = data_all.groupby(['Station','Lat','Lon'])['Sqrd difference'].sum().reset_index()
n_sample = data_all.groupby(['Station','Lat','Lon'])['Sqrd difference'].count().reset_index()
obs_mean = data_all.groupby(['Station','Lat','Lon'])['DO obs'].mean().reset_index()




nrmse = ( sqrd_difference['Sqrd difference'] / n_sample['Sqrd difference'] ).pow(0.5) / obs_mean['DO obs']
nrmse = pd.DataFrame(nrmse,columns=['NRMSE'])




nrmse['n'] = n_sample['Sqrd difference']
nrmse = nrmse.loc[nrmse['n']>=5]
nrmse = nrmse['NRMSE']



print(np.median(nrmse))


#########################################################################################################



hybrid_all = pd.read_csv('/scratch/depfg/graha010/Machine learning/x_test_Final_1.csv',sep=',')
hybrid_all = hybrid_all[['Station','Day','Lat','Lon','DO obs','Hybrid oxygen']]
hybrid_all = hybrid_all.sort_values(['Station','Day','Lat','Lon'],ascending=[True,True,True,True])
hybrid_all = hybrid_all.reset_index(drop=True)

print('Quick check')
hybrid_all = hybrid_all.dropna()
print(len(hybrid_all))
print('Quick check done')
exit()

observed = hybrid_all['DO obs']
simulated = hybrid_all['Hybrid oxygen']                 # Note: Hybrid oxygen! 
difference = simulated - observed
difference_sqrd = difference.pow(2)
hybrid_all['Sqrd difference'] = difference_sqrd



sqrd_difference = hybrid_all.groupby(['Station','Lat','Lon'])['Sqrd difference'].sum().reset_index()
n_sample = hybrid_all.groupby(['Station','Lat','Lon'])['Sqrd difference'].count().reset_index()
obs_mean = hybrid_all.groupby(['Station','Lat','Lon'])['DO obs'].mean().reset_index()



nrmse = ( sqrd_difference['Sqrd difference'] / n_sample['Sqrd difference'] ).pow(0.5) / obs_mean['DO obs']
nrmse = pd.DataFrame(nrmse,columns=['NRMSE'])



nrmse['n'] = n_sample['Sqrd difference']
nrmse = nrmse.loc[nrmse['n']>=5]
nrmse = nrmse['NRMSE']


print(np.median(nrmse))








## Firstly get the percentiles for each station based on whole dataset

x = ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
'22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
'46','47','48','49','50','51','52','53']

data_all = pd.DataFrame()

for ii in x:

  data = pd.read_csv('/scratch/depfg/graha010/Training data/' + ii + '.csv',sep=',')
  data_all = pd.concat([data_all,data])
  
data_all = data_all.sort_values(['Station','Day','Unit','Lat','Lon'],ascending=[True,True,True,True,True])
data_all = data_all.reset_index(drop=True)

percentiles = data_all.groupby('Station')['DO obs'].quantile(0.1).reset_index(name='Percentile')




## Now just load the testing dataset
data_all = pd.read_csv('/scratch/depfg/graha010/Machine learning/x_test_Final_1.csv',sep=',')
data_all = data_all[['Station','Lat','Lon','Day','DO obs','oxygen','Hybrid oxygen']].drop_duplicates()



## Merge with percentiles 
data_all = data_all.merge(percentiles,how='left',on=['Station'])
data_all = data_all.loc[data_all['DO obs'] < data_all['Percentile']]
#######################################################################



## DYNQUAL 


observed = data_all['DO obs']
simulated = data_all['oxygen']           
difference = simulated - observed
difference_sqrd = difference.pow(2)
data_all['Sqrd difference'] = difference_sqrd


sqrd_difference = data_all.groupby(['Station','Lat','Lon'])['Sqrd difference'].sum().reset_index()
n_sample = data_all.groupby(['Station','Lat','Lon'])['Sqrd difference'].count().reset_index()
obs_mean = data_all.groupby(['Station','Lat','Lon'])['DO obs'].mean().reset_index()



nrmse = ( sqrd_difference['Sqrd difference'] / n_sample['Sqrd difference'] ).pow(0.5) / obs_mean['DO obs']
nrmse = pd.DataFrame(nrmse,columns=['NRMSE'])



nrmse['n'] = n_sample['Sqrd difference']
nrmse = nrmse.loc[nrmse['n']>4]
nrmse = nrmse['NRMSE']


median_nrmse = np.median(nrmse)


print(median_nrmse)


#########################################################################################################



## DYNQUAL-RF 

observed = data_all['DO obs']
simulated = data_all['Hybrid oxygen']                                      ## NOTE THIS IS THE DIFFERENCE (HYBRID)     
difference = simulated - observed
difference_sqrd = difference.pow(2)
data_all['Sqrd difference'] = difference_sqrd


sqrd_difference = data_all.groupby(['Station','Lat','Lon'])['Sqrd difference'].sum().reset_index()
n_sample = data_all.groupby(['Station','Lat','Lon'])['Sqrd difference'].count().reset_index()
obs_mean = data_all.groupby(['Station','Lat','Lon'])['DO obs'].mean().reset_index()



nrmse = ( sqrd_difference['Sqrd difference'] / n_sample['Sqrd difference'] ).pow(0.5) / obs_mean['DO obs']
nrmse = pd.DataFrame(nrmse,columns=['NRMSE'])



nrmse['n'] = n_sample['Sqrd difference']
nrmse = nrmse.loc[nrmse['n']>4]
nrmse = nrmse['NRMSE']


median_nrmse = np.median(nrmse)


print(median_nrmse)







data_all = pd.read_csv('/scratch/depfg/graha010/Machine learning/x_test_Final_1.csv',sep=',')
data_all = data_all[['Station','Day','Lat','Lon','DO obs','oxygen','Hybrid oxygen']]
data_all = data_all.sort_values(['Station','Day','Lat','Lon'],ascending=[True,True,True,True])
data_all = data_all.reset_index(drop=True)



process_based = data_all.copy()
hybrid = data_all.copy()


## DYNQUAL 
observed = process_based['DO obs']
simulated = process_based['oxygen']   
difference = observed - simulated
process_based['Difference'] = difference
               
difference = process_based.groupby(['Station','Lat','Lon'])['Difference'].sum().reset_index()
n_sample = process_based.groupby(['Station','Lat','Lon'])['Difference'].count().reset_index()
obs_sum = process_based.groupby(['Station', 'Lat','Lon'])['DO obs'].sum().reset_index()

pbias = 100 * difference['Difference'] / obs_sum['DO obs']
pbias = pd.DataFrame(pbias,columns=['PBIAS'])

pbias['n'] = n_sample['Difference']
pbias = pbias.loc[pbias['n']>=5]
pbias = pbias['PBIAS']

print(np.median(pbias))

#########################################################################################################



## HYBRID model

observed = hybrid['DO obs']
simulated = hybrid['Hybrid oxygen']     
difference = observed - simulated
hybrid['Difference'] = difference
             

difference = hybrid.groupby(['Station','Lat','Lon'])['Difference'].sum().reset_index()
n_sample = hybrid.groupby(['Station','Lat','Lon'])['Difference'].count().reset_index()
obs_sum = hybrid.groupby(['Station', 'Lat','Lon'])['DO obs'].sum().reset_index()

pbias = 100 * difference['Difference'] / obs_sum['DO obs']
pbias = pd.DataFrame(pbias,columns=['PBIAS'])

pbias['n'] = n_sample['Difference']
pbias = pbias.loc[pbias['n']>=5]
pbias = pbias['PBIAS']

print(np.median(pbias))



data_all = pd.read_csv('/scratch/depfg/graha010/Machine learning/x_test_Final_1.csv',sep=',')
data_all = data_all[['Station','Day','Lat','Lon','DO obs','oxygen']]
data_all = data_all.sort_values(['Station','Day','Lat','Lon'],ascending=[True,True,True,True])
data_all = data_all.reset_index(drop=True)



data_all['Year'] = data_all['Day'].astype(str).str[:3]



observed = data_all['DO obs']
simulated = data_all['oxygen']                  
difference = simulated - observed
difference_sqrd = difference.pow(2)
data_all['Sqrd difference'] = difference_sqrd


sqrd_difference = data_all.groupby(['Station','Lat','Lon','Year'])['Sqrd difference'].sum().reset_index()
n_sample = data_all.groupby(['Station','Lat','Lon','Year'])['Sqrd difference'].count().reset_index()
obs_mean = data_all.groupby(['Station','Lat','Lon','Year'])['DO obs'].mean().reset_index()



nrmse = ( sqrd_difference['Sqrd difference'] / n_sample['Sqrd difference'] ).pow(0.5) / obs_mean['DO obs']
nrmse = pd.DataFrame(nrmse,columns=['NRMSE'])
nrmse['Year'] = sqrd_difference['Year']
nrmse['n'] = n_sample['Sqrd difference']


nrmse = nrmse.loc[nrmse['n']>4]


nrmse_1 = nrmse.groupby(['Year'])['NRMSE'].mean()


#########################################################################################################


hybrid_all = pd.read_csv('/scratch/depfg/graha010/Machine learning/x_test_Final_1.csv',sep=',')
hybrid_all = hybrid_all[['Station','Day','Lat','Lon','DO obs','Hybrid oxygen']]
hybrid_all = hybrid_all.sort_values(['Station','Day','Lat','Lon'],ascending=[True,True,True,True])
hybrid_all = hybrid_all.reset_index(drop=True)


hybrid_all['Year'] = hybrid_all['Day'].astype(str).str[:3]

  
observed = hybrid_all['DO obs']
simulated = hybrid_all['Hybrid oxygen']                 # Note: Hybrid oxygen! 
difference = simulated - observed
difference_sqrd = difference.pow(2)
hybrid_all['Sqrd difference'] = difference_sqrd


sqrd_difference = hybrid_all.groupby(['Station','Lat','Lon','Year'])['Sqrd difference'].sum().reset_index()
n_sample = hybrid_all.groupby(['Station','Lat','Lon','Year'])['Sqrd difference'].count().reset_index()
obs_mean = hybrid_all.groupby(['Station','Lat','Lon','Year'])['DO obs'].mean().reset_index()



nrmse = ( sqrd_difference['Sqrd difference'] / n_sample['Sqrd difference'] ).pow(0.5) / obs_mean['DO obs']
nrmse = pd.DataFrame(nrmse,columns=['NRMSE'])
nrmse['Year'] = sqrd_difference['Year']
nrmse['n'] = n_sample['Sqrd difference']



nrmse = nrmse.loc[nrmse['n']>4]


nrmse_2 = nrmse.groupby(['Year'])['NRMSE'].mean()



## !!
decadal = 100*(nrmse_1 - nrmse_2)/nrmse_1
print(decadal)



## !!
print(np.mean(decadal))


