

import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd


################################################################################################
ds_1_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M01_DO.nc',mode = 'r')

ds_2_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M02_DO.nc',mode = 'r')

ds_3_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M03_DO.nc',mode = 'r')

ds_4_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M04_DO.nc',mode = 'r')

ds_5_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M05_DO.nc',mode = 'r')

ds_6_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M06_DO.nc',mode = 'r')

ds_7_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M07_DO.nc',mode = 'r')

ds_8_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M08_DO.nc',mode = 'r')

ds_9_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M09_DO.nc',mode = 'r')

ds_10_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M10_DO.nc',mode = 'r')
#################################################################################################


################################################################################################
ds_11_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M11_DO.nc',mode = 'r')

ds_12_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M12_DO.nc',mode = 'r')

ds_13_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M13_DO.nc',mode = 'r')

ds_14_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M14_DO.nc',mode = 'r')

ds_15_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M15_DO.nc',mode = 'r')

ds_16_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M16_DO.nc',mode = 'r')

ds_17_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M17_DO.nc',mode = 'r')

ds_18_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M18_DO.nc',mode = 'r')

ds_19_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M19_DO.nc',mode = 'r')

ds_20_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M20_DO.nc',mode = 'r')
#################################################################################################


################################################################################################
ds_21_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M21_DO.nc',mode = 'r')

ds_22_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M22_DO.nc',mode = 'r')

ds_23_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M23_DO.nc',mode = 'r')

ds_24_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M24_DO.nc',mode = 'r')

ds_25_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M25_DO.nc',mode = 'r')

ds_26_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M26_DO.nc',mode = 'r')

ds_27_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M27_DO.nc',mode = 'r')

ds_30_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M30_DO.nc',mode = 'r')
#################################################################################################


################################################################################################
ds_31_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M31_DO.nc',mode = 'r')

ds_32_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M32_DO.nc',mode = 'r')

ds_33_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M33_DO.nc',mode = 'r')

ds_34_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M34_DO.nc',mode = 'r')

ds_35_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M35_DO.nc',mode = 'r')

ds_36_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M36_DO.nc',mode = 'r')

ds_37_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M37_DO.nc',mode = 'r')

ds_38_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M38_DO.nc',mode = 'r')

ds_39_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M39_DO.nc',mode = 'r')

ds_40_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M40_DO.nc',mode = 'r')
#################################################################################################


################################################################################################
ds_41_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M41_DO.nc',mode = 'r')

ds_42_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M42_DO.nc',mode = 'r')

ds_43_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M43_DO.nc',mode = 'r')

ds_44_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M44_DO.nc',mode = 'r')

ds_45_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M45_DO.nc',mode = 'r')

ds_46_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M46_DO.nc',mode = 'r')

ds_47_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M47_DO.nc',mode = 'r')

ds_48_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M48_DO.nc',mode = 'r')

ds_49_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M49_DO.nc',mode = 'r')

ds_50_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M50_DO.nc',mode = 'r')
#################################################################################################


################################################################################################
ds_51_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M51_DO.nc',mode = 'r')

ds_52_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M52_DO.nc',mode = 'r')

ds_53_hyb = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M53_DO.nc',mode = 'r')
#################################################################################################









# Could have used any of the 53
time_len = ds_1_hyb['Hybrid_DO'].shape[0]









global_stress_all = []

for ii in range(0,time_len):

  values = pd.DataFrame()

  tmp = ds_1_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_2_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_3_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_4_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_5_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_6_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_7_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_8_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_9_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_10_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_11_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_12_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_13_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_14_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_15_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_16_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_17_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_18_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_19_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_20_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_21_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_22_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_23_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_24_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_25_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_26_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_27_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_30_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_31_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_32_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_33_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_34_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_35_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_36_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_37_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_38_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_39_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_40_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_41_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_42_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_43_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_44_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_45_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_46_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_47_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_48_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_49_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_50_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_51_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_52_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  tmp = ds_53_hyb['Hybrid_DO'][ii,:,:]
  tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
  tmp = pd.DataFrame(tmp,columns=['Tmp'])
  tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
  tmp = tmp.loc[(tmp['Tmp'] >= 0.0) & (tmp['Tmp'] < 3.0)]
  values = pd.concat([values,tmp])
  
  global_stress = len(values)
  global_stress_all.append(global_stress)

  print(ii)
  
global_stress_all = pd.DataFrame(global_stress_all)
global_stress_all = global_stress_all.reset_index(drop=True)
global_stress_all.to_csv('/scratch/depfg/graha010/Time-Series/time_series_3.csv',index=False)
















  
  
  
  