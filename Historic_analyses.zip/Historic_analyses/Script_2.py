

import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd 
from dateutil.relativedelta import *
from sklearn.ensemble import RandomForestRegressor
import joblib
from datetime import datetime
from sklearn.model_selection import train_test_split






## Load the training data ##
x = ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
'22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
'46','47','48','49','50','51','52','53']

data_all = pd.DataFrame()

for ii in x:

  data = pd.read_csv('/scratch/depfg/graha010/Training data/' + ii + '.csv',sep=',')
  data_all = pd.concat([data_all,data])
  
data_all = data_all.sort_values(['Station','Day','Unit','Lat','Lon'],ascending=[True,True,True,True,True])
data_all = data_all.reset_index(drop=True)





## Check the number of unique training data
data_all = data_all.dropna()
print('Number of unique data is ' + str(len(data_all)))



## Further tidy training data
data_all = data_all.dropna(subset=['DO obs','oxygen','discharge','waterTemperature','BOD_concentration','Lat','Lon'])
data_all['Delta'] = data_all['DO obs'] - data_all['oxygen']




## NOTE (Screening the uppermost anomalies):
print('Incorporating percentile process')
data_all = data_all.loc[data_all['DO obs'] < data_all['DO obs'].quantile(0.995)] 
print('Percentile process confirmed')


print(data_all['oxygen'].min())
print(data_all['oxygen'].max())
print(data_all['DO obs'].min())
print(data_all['DO obs'].max())



## New steps (Stratified sampling)
basins = pd.read_csv('/scratch/depfg/graha010/Basins/stations_with_basins.csv',sep=';')
basins = basins[['Station','HYBAS_ID']]
basins['HYBAS_ID'] = basins['HYBAS_ID'].str.split(',').str[0]
basins = basins.reset_index(drop=True)
data_all = data_all.merge(basins,how='left',on=['Station'])
data_all = data_all.dropna()  ## Stations which aren't linked to a basin




##### Get the year of each data point (e.g. 1980) 
tmp_dates = data_all['Day'].astype(str)
tmp_dates = tmp_dates.str[0:4]
data_all['YEAR'] = tmp_dates



## Group by river basin (HYBAS_ID) and YEAR
sample_size = data_all.groupby(['HYBAS_ID','YEAR'])['DO obs'].count().reset_index(name='Sample size')
data_all = data_all.merge(sample_size,how='left',on=['HYBAS_ID','YEAR'])



## Requirement for stratified sampling
data_all = data_all.loc[data_all['Sample size']>=2]   



## Check the length of the data at this point         
data_all = data_all.dropna()
print('The length of data_all here is ' + str(len(data_all)))



## Extract samples for machine learning ##
X = data_all[['discharge','waterTemperature','BOD_concentration','Lat','Lon','Day','Station','oxygen','DO obs','HYBAS_ID','YEAR']]
y = data_all['Delta']
X = np.array(X)
y = np.array(y)
strata = data_all[['HYBAS_ID','YEAR']]
strata = np.array(strata)

x_train, x_test, y_train, y_test = train_test_split(X, y, test_size=0.2, stratify=strata)




## Another check
print('Number of training points is ' + str(len(x_train)))




## Train the model using xtrain[:,0:3] and y_train ##
print('Training started')
print(datetime.now())
model = RandomForestRegressor()
model.fit(x_train[:,0:3],y_train)
joblib.dump(model,'/scratch/depfg/graha010/Machine learning/RF_Final_5.joblib')
print('Training finished')
print(datetime.now())




## Predict the residuals and save
x_test = pd.DataFrame(x_test,columns=['discharge','waterTemperature','BOD_concentration','Lat','Lon','Day','Station','oxygen','DO obs','HYBAS_ID','YEAR'])
x_test = x_test.reset_index(drop=True)

discharge = np.array(x_test['discharge'])
waterTemp = np.array(x_test['waterTemperature'])
bod = np.array(x_test['BOD_concentration'])


print('Predicting started')
print(datetime.now())
predicted = model.predict(np.c_[discharge,waterTemp,bod])
print('Predicting finished')
print(datetime.now())

  
x_test['Delta predict'] = predicted
x_test['Hybrid oxygen'] = x_test['oxygen'] + x_test['Delta predict']
x_test.to_csv('/scratch/depfg/graha010/Machine learning/x_test_Final_5.csv',index=False)


x_train = pd.DataFrame(x_train,columns=['discharge','waterTemperature','BOD_concentration','Lat','Lon','Day','Station','oxygen','DO obs','HYBAS_ID','YEAR'])
x_train.to_csv('/scratch/depfg/graha010/Machine learning/x_train_Final_5.csv',index=False)








