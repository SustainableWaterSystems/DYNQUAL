


import pandas as pd
import numpy as np 
from matplotlib import pyplot as plt
from numpy import hstack
import geopandas as gpd
import mapclassify
import netCDF4 as nc
import cartopy.crs as ccrs
from pylab import *





output_all = pd.DataFrame()
output_all_raw = pd.DataFrame()

for ii in ['26','27','30','32','33','34']:

  data = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M' + ii + '_DO.nc')
  oxygen = data['Hybrid_DO'][:,:,:]
  
  oxygen_dec1 = oxygen[0:3653,:,:]               
  oxygen_dec2 = oxygen[3653:7305,:,:]
  oxygen_dec3 = oxygen[7305:10958,:,:]
  oxygen_dec4 = oxygen[10958:14610,:,:]

  oxygen_dec1[(oxygen_dec1>=0) & (oxygen_dec1<5)] = 1
  oxygen_dec1[oxygen_dec1>=5] = 0
  oxygen_dec1[oxygen_dec1<0] = 0
  oxygen_dec1 = np.nansum(oxygen_dec1,axis=0)                                     

  oxygen_dec2[(oxygen_dec2>=0) & (oxygen_dec2<5)] = 1
  oxygen_dec2[oxygen_dec2>=5] = 0
  oxygen_dec2[oxygen_dec2<0] = 0
  oxygen_dec2 = np.nansum(oxygen_dec2,axis=0) 

  oxygen_dec3[(oxygen_dec3>=0) & (oxygen_dec3<5)] = 1
  oxygen_dec3[oxygen_dec3>=5] = 0
  oxygen_dec3[oxygen_dec3<0] = 0
  oxygen_dec3 = np.nansum(oxygen_dec3,axis=0) 

  oxygen_dec4[(oxygen_dec4>=0) & (oxygen_dec4<5)] = 1
  oxygen_dec4[oxygen_dec4>=5] = 0
  oxygen_dec4[oxygen_dec4<0] = 0
  oxygen_dec4 = np.nansum(oxygen_dec4,axis=0) 


  diff_1 = 100*(oxygen_dec2 - oxygen_dec1)/oxygen_dec1
  diff_2 = 100*(oxygen_dec3 - oxygen_dec2)/oxygen_dec2
  diff_3 = 100*(oxygen_dec4 - oxygen_dec3)/oxygen_dec3
  
  diff_1_raw = oxygen_dec2 - oxygen_dec1
  diff_2_raw = oxygen_dec3 - oxygen_dec2
  diff_3_raw = oxygen_dec4 - oxygen_dec3

  output = np.nanmean([diff_1,diff_2,diff_3], axis=0)  
  output[np.isnan(np.nanmean(oxygen,axis=0))] = np.nan
  output = np.reshape(output,output.shape[0]*output.shape[1])
  output = pd.DataFrame(output)
  output_all = pd.concat([output_all,output])
  
  output_raw = np.nanmean([diff_1_raw,diff_2_raw,diff_3_raw], axis=0)  
  output_raw[np.isnan(np.nanmean(oxygen,axis=0))] = np.nan
  output_raw = np.reshape(output_raw,output_raw.shape[0]*output_raw.shape[1])
  output_raw = pd.DataFrame(output_raw)
  output_all_raw = pd.concat([output_all_raw,output_raw])
  print(ii)
  

print('Europe / Stress / Prct')
print(np.nanmean(output_all))

print('Europe / Stress / Raw')
print(np.nanmean(output_all_raw))













output_all = pd.DataFrame()
output_all_raw = pd.DataFrame()

for ii in ['24','50','51','52','53']:

  data = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M' + ii + '_DO.nc')
  oxygen = data['Hybrid_DO'][:,:,:]
  
  oxygen_dec1 = oxygen[0:3653,:,:]               
  oxygen_dec2 = oxygen[3653:7305,:,:]
  oxygen_dec3 = oxygen[7305:10958,:,:]
  oxygen_dec4 = oxygen[10958:14610,:,:]

  oxygen_dec1[(oxygen_dec1>=0) & (oxygen_dec1<3)] = 1
  oxygen_dec1[oxygen_dec1>=3] = 0
  oxygen_dec1[oxygen_dec1<0] = 0
  oxygen_dec1 = np.nansum(oxygen_dec1,axis=0)                                     

  oxygen_dec2[(oxygen_dec2>=0) & (oxygen_dec2<3)] = 1
  oxygen_dec2[oxygen_dec2>=3] = 0
  oxygen_dec2[oxygen_dec2<0] = 0
  oxygen_dec2 = np.nansum(oxygen_dec2,axis=0) 

  oxygen_dec3[(oxygen_dec3>=0) & (oxygen_dec3<3)] = 1
  oxygen_dec3[oxygen_dec3>=3] = 0
  oxygen_dec3[oxygen_dec3<0] = 0
  oxygen_dec3 = np.nansum(oxygen_dec3,axis=0) 

  oxygen_dec4[(oxygen_dec4>=0) & (oxygen_dec4<3)] = 1
  oxygen_dec4[oxygen_dec4>=3] = 0
  oxygen_dec4[oxygen_dec4<0] = 0
  oxygen_dec4 = np.nansum(oxygen_dec4,axis=0) 


  diff_1 = 100*(oxygen_dec2 - oxygen_dec1)/oxygen_dec1
  diff_2 = 100*(oxygen_dec3 - oxygen_dec2)/oxygen_dec2
  diff_3 = 100*(oxygen_dec4 - oxygen_dec3)/oxygen_dec3
  
  diff_1_raw = oxygen_dec2 - oxygen_dec1
  diff_2_raw = oxygen_dec3 - oxygen_dec2
  diff_3_raw = oxygen_dec4 - oxygen_dec3
  
  output = np.nanmean([diff_1,diff_2,diff_3], axis=0)    
  output[np.isnan(np.nanmean(oxygen,axis=0))] = np.nan
  output = np.reshape(output,output.shape[0]*output.shape[1])
  output = pd.DataFrame(output)
  output_all = pd.concat([output_all,output])
  
  output_raw = np.nanmean([diff_1_raw,diff_2_raw,diff_3_raw], axis=0)    
  output_raw[np.isnan(np.nanmean(oxygen,axis=0))] = np.nan
  output_raw = np.reshape(output_raw,output_raw.shape[0]*output_raw.shape[1])
  output_raw = pd.DataFrame(output_raw)
  output_all_raw = pd.concat([output_all_raw,output_raw])
  
  print(ii)
  
  
print('South America / Hypoxia / Prct')
print(np.nanmean(output_all))

print('South America / Hypoxia / Raw')
print(np.nanmean(output_all_raw))





























output_all = pd.DataFrame()
output_all_raw = pd.DataFrame()

for ii in ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
'22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
'46','47','48','49','50','51','52','53']:

  data = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M' + ii + '_DO.nc')
  oxygen = data['Hybrid_DO'][:,:,:]
  
  oxygen_dec1 = oxygen[0:3653,:,:]               
  oxygen_dec2 = oxygen[3653:7305,:,:]
  oxygen_dec3 = oxygen[7305:10958,:,:]
  oxygen_dec4 = oxygen[10958:14610,:,:]


  oxygen_dec1[(oxygen_dec1>=0) & (oxygen_dec1<5)] = 1
  oxygen_dec1[oxygen_dec1>=5] = 0
  oxygen_dec1[oxygen_dec1<0] = 0
  oxygen_dec1 = np.nansum(oxygen_dec1,axis=0)                                     

  oxygen_dec2[(oxygen_dec2>=0) & (oxygen_dec2<5)] = 1
  oxygen_dec2[oxygen_dec2>=5] = 0
  oxygen_dec2[oxygen_dec2<0] = 0
  oxygen_dec2 = np.nansum(oxygen_dec2,axis=0) 

  oxygen_dec3[(oxygen_dec3>=0) & (oxygen_dec3<5)] = 1
  oxygen_dec3[oxygen_dec3>=5] = 0
  oxygen_dec3[oxygen_dec3<0] = 0
  oxygen_dec3 = np.nansum(oxygen_dec3,axis=0) 

  oxygen_dec4[(oxygen_dec4>=0) & (oxygen_dec4<5)] = 1
  oxygen_dec4[oxygen_dec4>=5] = 0
  oxygen_dec4[oxygen_dec4<0] = 0
  oxygen_dec4 = np.nansum(oxygen_dec4,axis=0) 


  diff_1 = 100*(oxygen_dec2 - oxygen_dec1)/oxygen_dec1
  diff_2 = 100*(oxygen_dec3 - oxygen_dec2)/oxygen_dec2
  diff_3 = 100*(oxygen_dec4 - oxygen_dec3)/oxygen_dec3
  
  diff_1_raw = oxygen_dec2 - oxygen_dec1
  diff_2_raw = oxygen_dec3 - oxygen_dec2
  diff_3_raw = oxygen_dec4 - oxygen_dec3

  output = np.nanmean([diff_1,diff_2,diff_3], axis=0)  
  output[np.isnan(np.nanmean(oxygen,axis=0))] = np.nan
  output = np.reshape(output,output.shape[0]*output.shape[1])
  output = pd.DataFrame(output)
  output_all = pd.concat([output_all,output])
  
  output_raw = np.nanmean([diff_1_raw,diff_2_raw,diff_3_raw], axis=0) 
  output_raw[np.isnan(np.nanmean(oxygen,axis=0))] = np.nan 
  output_raw = np.reshape(output_raw,output_raw.shape[0]*output_raw.shape[1])
  output_raw = pd.DataFrame(output_raw)
  output_all_raw = pd.concat([output_all_raw,output_raw])
  print(ii)
  

print('Global / Stress / Prct')
print(np.nanmean(output_all))

print('Global / Stress / Raw')
print(np.nanmean(output_all_raw))












output_all = pd.DataFrame()
output_all_raw = pd.DataFrame()

for ii in ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
'22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
'46','47','48','49','50','51','52','53']:

  data = nc.Dataset('/scratch/depfg/graha010/Post_Processed_Hybrid_DO_Historic_June_19/M' + ii + '_DO.nc')
  oxygen = data['Hybrid_DO'][:,:,:]
  
  oxygen_dec1 = oxygen[0:3653,:,:]               
  oxygen_dec2 = oxygen[3653:7305,:,:]
  oxygen_dec3 = oxygen[7305:10958,:,:]
  oxygen_dec4 = oxygen[10958:14610,:,:]

  oxygen_dec1[(oxygen_dec1>=0) & (oxygen_dec1<3)] = 1
  oxygen_dec1[oxygen_dec1>=3] = 0
  oxygen_dec1[oxygen_dec1<0] = 0
  oxygen_dec1 = np.nansum(oxygen_dec1,axis=0)                                     

  oxygen_dec2[(oxygen_dec2>=0) & (oxygen_dec2<3)] = 1
  oxygen_dec2[oxygen_dec2>=3] = 0
  oxygen_dec2[oxygen_dec2<0] = 0
  oxygen_dec2 = np.nansum(oxygen_dec2,axis=0) 

  oxygen_dec3[(oxygen_dec3>=0) & (oxygen_dec3<3)] = 1
  oxygen_dec3[oxygen_dec3>=3] = 0
  oxygen_dec3[oxygen_dec3<0] = 0
  oxygen_dec3 = np.nansum(oxygen_dec3,axis=0) 

  oxygen_dec4[(oxygen_dec4>=0) & (oxygen_dec4<3)] = 1
  oxygen_dec4[oxygen_dec4>=3] = 0
  oxygen_dec4[oxygen_dec4<0] = 0
  oxygen_dec4 = np.nansum(oxygen_dec4,axis=0) 


  diff_1 = 100*(oxygen_dec2 - oxygen_dec1)/oxygen_dec1
  diff_2 = 100*(oxygen_dec3 - oxygen_dec2)/oxygen_dec2
  diff_3 = 100*(oxygen_dec4 - oxygen_dec3)/oxygen_dec3
  
  diff_1_raw = oxygen_dec2 - oxygen_dec1
  diff_2_raw = oxygen_dec3 - oxygen_dec2
  diff_3_raw = oxygen_dec4 - oxygen_dec3
  
  output = np.nanmean([diff_1,diff_2,diff_3], axis=0)    
  output[np.isnan(np.nanmean(oxygen,axis=0))] = np.nan
  output = np.reshape(output,output.shape[0]*output.shape[1])
  output = pd.DataFrame(output)
  output_all = pd.concat([output_all,output])
  
  output_raw = np.nanmean([diff_1_raw,diff_2_raw,diff_3_raw], axis=0)    
  output_raw[np.isnan(np.nanmean(oxygen,axis=0))] = np.nan
  output_raw = np.reshape(output_raw,output_raw.shape[0]*output_raw.shape[1])
  output_raw = pd.DataFrame(output_raw)
  output_all_raw = pd.concat([output_all_raw,output_raw])
  
  print(ii)
  
  
print('Global / Hypoxia / Prct')
print(np.nanmean(output_all))
print('Global / Hypoxia / Raw')
print(np.nanmean(output_all_raw))












