



import pandas as pd
from matplotlib import pyplot as plt
from datetime import datetime, timedelta
import matplotlib.dates as mdates
import numpy as np
from matplotlib.lines import Line2D
import pymannkendall as mk










## Get a list of dates
start_date = datetime(1980, 1, 1)
end_date = datetime(2019, 12, 31)
 
date_list = []
 
while start_date <= end_date:
    date_list.append(start_date)
    start_date += timedelta(days=1)
 
date_list = pd.DataFrame(date_list,columns=['time'])







## Read the global daily average DO
do_series = pd.read_csv('/scratch/depfg/graha010/Time-Series/time_series_1.csv')
do_series = do_series.rename(columns={'0': "Global DO"})
do_series['time'] = date_list


do_series['time'] = do_series['time'].astype(str).str[:3]
do_series = do_series.groupby(['time'])['Global DO'].mean().reset_index()          ## NOTE: MEAN
print(do_series)
do_series_1 = do_series.iloc[1,1] - do_series.iloc[0,1]
do_series_2 = do_series.iloc[2,1] - do_series.iloc[1,1]
do_series_3 = do_series.iloc[3,1] - do_series.iloc[2,1]
do_series_avg = (do_series_1 + do_series_2 + do_series_3)/3
print(do_series_avg)







## Read the stress time series
do_series = pd.read_csv('/scratch/depfg/graha010/Time-Series/time_series_2.csv')
do_series = do_series.rename(columns={'0': "N"})
do_series['time'] = date_list


do_series['time'] = do_series['time'].astype(str).str[:3]
do_series = do_series.groupby(['time'])['N'].mean().reset_index()                   ## NOTE: MEAN
print(do_series)
do_series_1 = do_series.iloc[1,1] - do_series.iloc[0,1]
do_series_2 = do_series.iloc[2,1] - do_series.iloc[1,1]
do_series_3 = do_series.iloc[3,1] - do_series.iloc[2,1]
do_series_avg = (do_series_1 + do_series_2 + do_series_3)/3
print(do_series_avg)









## Read the hypoxia time series
do_series = pd.read_csv('/scratch/depfg/graha010/Time-Series/time_series_3.csv')
do_series = do_series.rename(columns={'0': "N"})
do_series['time'] = date_list


do_series['time'] = do_series['time'].astype(str).str[:3]
do_series = do_series.groupby(['time'])['N'].mean().reset_index()                  ##: NOTE: MEAN
print(do_series)
do_series_1 = do_series.iloc[1,1] - do_series.iloc[0,1]
do_series_2 = do_series.iloc[2,1] - do_series.iloc[1,1]
do_series_3 = do_series.iloc[3,1] - do_series.iloc[2,1]
do_series_avg = (do_series_1 + do_series_2 + do_series_3)/3
print(do_series_avg)




