

import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd 
import datetime
from dateutil.relativedelta import *



## Model locations ###########################################################################################
x = ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
'22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
'46','47','48','49','50','51','52','53']

lat_all = pd.DataFrame()
lon_all = pd.DataFrame()

for ii in x: 
  fn = '/scratch/depfg/graha010/DYNQUAL_GLOBAL_OUTPUT_ONLINE/M' + ii + '/netcdf/oxygen_dailyTot_output.nc'
  ds = nc.Dataset(fn)
  
  lat_dynqual = ds['lat'][:]
  lat_dynqual = pd.DataFrame(lat_dynqual)

  lon_dynqual = ds['lon'][:]
  lon_dynqual = pd.DataFrame(lon_dynqual)
  
  lat_all = pd.concat([lat_all, lat_dynqual])
  lon_all = pd.concat([lon_all, lon_dynqual])
  
lat_all = lat_all.drop_duplicates().reset_index(drop=True)
lon_all = lon_all.drop_duplicates().reset_index(drop=True)
##############################################################################################################



## Include M28 and M29 #######################################################################################
m28 = '/depfg/sutan101/data/dynqual_input/copied_from_snellius_on_2023-03-22/clone_maps/mask_M28.nc'
m28 = nc.Dataset(m28)
m28_lat = m28['lat'][:]
m28_lat = pd.DataFrame(m28_lat)
m28_lon = m28['lon'][:]
m28_lon = pd.DataFrame(m28_lon)

m29 = '/depfg/sutan101/data/dynqual_input/copied_from_snellius_on_2023-03-22/clone_maps/mask_M29.nc'
m29 = nc.Dataset(m29)
m29_lat = m29['lat'][:]
m29_lat = pd.DataFrame(m29_lat)
m29_lon = m29['lon'][:]
m29_lon = pd.DataFrame(m29_lon)

lat_all = pd.concat([lat_all,m28_lat,m29_lat])
lon_all = pd.concat([lon_all,m28_lon,m29_lon])

lat_all = lat_all.drop_duplicates().reset_index(drop=True)
lon_all = lon_all.drop_duplicates().reset_index(drop=True)
###############################################################################################################



del ds

## Station locations ###########################################################################################
observational_data = pd.read_csv('/scratch/depfg/graha010/OXYGEN_ALL.csv',sep=';')
data_lat = observational_data['Lat'].drop_duplicates().reset_index(drop=True)
data_lon = observational_data['Lon'].drop_duplicates().reset_index(drop=True)


data_lat_new = pd.DataFrame()
for ii in range(0,len(data_lat)):
  value = data_lat.iloc[ii]
  compare = abs(lat_all - value)
  minimum = compare.idxmin()
  new_value = lat_all.iloc[minimum]
  data_lat_new = pd.concat([data_lat_new,new_value])
data_lat_new = data_lat_new.reset_index(drop=True)
print('Lats converted')


data_lon_new = pd.DataFrame()
for ii in range(0,len(data_lon)):
  value = data_lon.iloc[ii]
  compare = abs(lon_all - value)
  minimum = compare.idxmin()
  new_value = lon_all.iloc[minimum]
  data_lon_new = pd.concat([data_lon_new,new_value])
data_lon_new = data_lon_new.reset_index(drop=True)
print('Lons converted')


data_lat = pd.DataFrame(data_lat)
data_lon = pd.DataFrame(data_lon)
data_lat['Lat new'] = data_lat_new
data_lon['Lon new'] = data_lon_new
###############################################################################################################


## Update the station locations ###############################################################################
observational_data = observational_data.merge(data_lat,on='Lat',how='left')
observational_data = observational_data.merge(data_lon,on='Lon',how='left')

observational_data['Lat'] = observational_data['Lat new']
observational_data['Lon'] = observational_data['Lon new']

observational_data = observational_data.drop(columns=['Lat new', 'Lon new'])

del data_lat
del data_lon
del data_lat_new
del data_lon_new
################################################################################################################




## Merge DO obs and DO sim for each landmask ###################################################################
MM = ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
'22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
'46','47','48','49','50','51','52','53']

for ii in MM: 


  fn = '/scratch/depfg/graha010/DYNQUAL_GLOBAL_OUTPUT_ONLINE/M' + ii + '/netcdf/oxygen_dailyTot_output.nc'
  ds = nc.Dataset(fn)

  fn_2 = '/scratch/depfg/graha010/DYNQUAL_GLOBAL_OUTPUT_ONLINE/M' + ii + '/netcdf/discharge_dailyTot_output.nc'
  ds_2 = nc.Dataset(fn_2)

  fn_3 = '/scratch/depfg/graha010/DYNQUAL_GLOBAL_OUTPUT_ONLINE/M' + ii + '/netcdf/waterTemp_dailyTot_output.nc'
  ds_3 = nc.Dataset(fn_3)
  
  fn_4 = '/scratch/depfg/graha010/DYNQUAL_GLOBAL_OUTPUT_ONLINE/M' + ii + '/netcdf/BOD_concentration_dailyTot_output.nc'
  ds_4 = nc.Dataset(fn_4)


  
  start_date = datetime.date(1980, 1, 1)
  sample_all = pd.DataFrame()

  for XX in range(0,14610):
  
    start_date_str = start_date.strftime("%Y-%m-%d")
    sample = observational_data.loc[observational_data['Day']==start_date_str]
    
    ###########################################################################################################
    x = ds['oxygen'][XX,:,:]
    x = pd.DataFrame(x)
  
    y = ds['lat'][:]
    y = pd.DataFrame(y)
    y = pd.concat([y]*len(x.columns), axis=1, ignore_index=True)
  
    z = ds['lon'][:]
    z = pd.DataFrame(z)
    z = z.T
    z = pd.concat([z]*len(x), axis=0, ignore_index=True)

    x = pd.melt(x,value_name = 'oxygen').reset_index(drop=True)
    y = pd.melt(y,value_name = 'Lat').reset_index(drop=True)
    z = pd.melt(z,value_name = 'Lon').reset_index(drop=True)
    ############################################################################################################
  
  
    #############################################################################################################
    aa = ds_2['discharge'][XX,:,:]
    aa = pd.DataFrame(aa)
    aa = pd.melt(aa,value_name = 'discharge').reset_index(drop=True)
    #############################################################################################################
  
  
    #############################################################################################################
    bb = ds_3['waterTemperature'][XX,:,:]
    bb = pd.DataFrame(bb)
    bb = pd.melt(bb,value_name = 'waterTemperature').reset_index(drop=True)
    #############################################################################################################
  
  
    #############################################################################################################
    cc = ds_4['BOD_concentration'][XX,:,:]
    cc = pd.DataFrame(cc)
    cc = pd.melt(cc,value_name = 'BOD_concentration').reset_index(drop=True)
    #############################################################################################################
  
  
    data = pd.DataFrame(x['oxygen'])
    data['Lat'] = y['Lat']
    data['Lon'] = z['Lon']
    data['discharge'] = aa['discharge']
    data['waterTemperature'] = bb['waterTemperature']
    data['BOD_concentration'] = cc['BOD_concentration']
    data['Day'] = start_date_str
  
    sample = sample.merge(data,on=['Lat','Lon','Day'],how='left')
    sample = sample.dropna(subset=['waterTemperature'])              # At least has waterTemperature
          
    sample_all = pd.concat([sample_all,sample])
  
    start_date += relativedelta(days=1)
  

  sample_all.to_csv('/scratch/depfg/graha010/Training data/' + ii + '.csv',index=False)
##################################################################################################################


  
  