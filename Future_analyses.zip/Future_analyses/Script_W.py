


import pandas as pd
from matplotlib import pyplot as plt
from datetime import datetime, timedelta
import matplotlib.dates as mdates
import numpy as np
from matplotlib.lines import Line2D
import pymannkendall as mk
from sklearn.linear_model import LinearRegression
from sklearn.datasets import make_regression
import statsmodels.api as sm
from statsmodels.formula.api import ols
from statsmodels.stats.anova import anova_lm






tw_exp_all = []
bod_exp_all = []
q_exp_all = []

for GCM in ['GFDL','IPSL','MPI','MRI','UKESM']:


  ## Multiple linear regression 

  tw_series_1 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_waterTemp_2021-2030' + '_' + GCM + '.csv')
  tw_series_2 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_waterTemp_2031-2040' + '_' + GCM + '.csv')
  tw_series_3 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_waterTemp_2041-2050' + '_' + GCM + '.csv')
  tw_series_4 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_waterTemp_2051-2060' + '_' + GCM + '.csv')
  tw_series_5 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_waterTemp_2061-2070' + '_' + GCM + '.csv')
  tw_series_6 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_waterTemp_2071-2080' + '_' + GCM + '.csv')
  tw_series_7 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_waterTemp_2081-2090' + '_' + GCM + '.csv')
  tw_series_8 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_waterTemp_2091-2100' + '_' + GCM + '.csv')
  tw_series = pd.concat([tw_series_1,tw_series_2,tw_series_3,tw_series_4,tw_series_5,tw_series_6,tw_series_7,tw_series_8])


  bod_series_1 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_BOD_concentration_2021-2030' + '_' + GCM + '.csv')
  bod_series_2 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_BOD_concentration_2031-2040' + '_' + GCM + '.csv')
  bod_series_3 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_BOD_concentration_2041-2050' + '_' + GCM + '.csv')
  bod_series_4 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_BOD_concentration_2051-2060' + '_' + GCM + '.csv')
  bod_series_5 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_BOD_concentration_2061-2070' + '_' + GCM + '.csv')
  bod_series_6 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_BOD_concentration_2071-2080' + '_' + GCM + '.csv')
  bod_series_7 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_BOD_concentration_2081-2090' + '_' + GCM + '.csv')
  bod_series_8 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_BOD_concentration_2091-2100' + '_' + GCM + '.csv')
  bod_series = pd.concat([bod_series_1,bod_series_2,bod_series_3,bod_series_4,bod_series_5,bod_series_6,bod_series_7,bod_series_8])


  q_series_1 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_discharge_2021-2030' + '_' + GCM + '.csv')
  q_series_2 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_discharge_2031-2040' + '_' + GCM + '.csv')
  q_series_3 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_discharge_2041-2050' + '_' + GCM + '.csv')
  q_series_4 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_discharge_2051-2060' + '_' + GCM + '.csv')
  q_series_5 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_discharge_2061-2070' + '_' + GCM + '.csv')
  q_series_6 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_discharge_2071-2080' + '_' + GCM + '.csv')
  q_series_7 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_discharge_2081-2090' + '_' + GCM + '.csv')
  q_series_8 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_discharge_2091-2100' + '_' + GCM + '.csv')
  q_series = pd.concat([q_series_1,q_series_2,q_series_3,q_series_4,q_series_5,q_series_6,q_series_7,q_series_8])
  
  
  do_series_1 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_oxy_2021-2030' + '_' + GCM + '.csv')
  do_series_2 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_oxy_2031-2040' + '_' + GCM + '.csv')
  do_series_3 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_oxy_2041-2050' + '_' + GCM + '.csv')
  do_series_4 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_oxy_2051-2060' + '_' + GCM + '.csv')
  do_series_5 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_oxy_2061-2070' + '_' + GCM + '.csv')
  do_series_6 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_oxy_2071-2080' + '_' + GCM + '.csv')
  do_series_7 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_oxy_2081-2090' + '_' + GCM + '.csv')
  do_series_8 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/avg_oxy_2091-2100' + '_' + GCM + '.csv')
  do_series = pd.concat([do_series_1,do_series_2,do_series_3,do_series_4,do_series_5,do_series_6,do_series_7,do_series_8])


  
  tw_series = tw_series.rename(columns={'0':'tw'})
  bod_series = bod_series.rename(columns={'0':'bod'})
  q_series = q_series.rename(columns={'0':'q'})
  do_series = do_series.rename(columns={'0':'do'})
  

  x = pd.concat([tw_series,bod_series,q_series,do_series],axis=1)


  lm = ols('do ~ tw + bod + q',x).fit()
  anova_table = anova_lm(lm)

  tw_exp = anova_table.loc['tw','sum_sq'] / anova_table['sum_sq'].sum()
  bod_exp = anova_table.loc['bod','sum_sq'] / anova_table['sum_sq'].sum()
  q_exp = anova_table.loc['q','sum_sq'] / anova_table['sum_sq'].sum()

  tw_exp_all.append(tw_exp)
  bod_exp_all.append(bod_exp)
  q_exp_all.append(q_exp)
  
  
tw_exp_all = pd.DataFrame(tw_exp_all)
bod_exp_all = pd.DataFrame(bod_exp_all)
q_exp_all = pd.DataFrame(q_exp_all)


print(tw_exp_all)
print(tw_exp_all.mean())
print(tw_exp_all.std())

print(bod_exp_all)
print(bod_exp_all.mean())
print(bod_exp_all.std())

print(q_exp_all)
print(q_exp_all.mean())
print(q_exp_all.std())




















