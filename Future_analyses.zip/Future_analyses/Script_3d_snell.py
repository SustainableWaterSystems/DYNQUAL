


import netCDF4 as nc
import numpy as np
import pandas as pd 
from sklearn.ensemble import RandomForestRegressor
import joblib
from datetime import datetime



## Load the random forest 
model = joblib.load("/gpfs/work4/0/einf6448/RF_Final_1.joblib")



for period in ['2005-2014','2015-2020','2021-2030','2031-2040','2041-2050','2051-2060','2061-2070','2071-2080','2081-2090','2091-2100']:

  for region in ['M31','M32','M33','M34','M35','M36','M37','M38','M39','M40']:

    # oxygen 
    fn_1 = '/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_GFDL_SSP3RCP7/'+period+'/'+region+'/netcdf/oxygen_dailyTot_output.nc'
    ds_1 = nc.Dataset(fn_1)

    # bod    
    fn_2 = '/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_GFDL_SSP3RCP7/'+period+'/'+region+'/netcdf/BOD_concentration_dailyTot_output.nc'
    ds_2 = nc.Dataset(fn_2)

    # waterTemp
    fn_3 = '/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_GFDL_SSP3RCP7/'+period+'/'+region+'/netcdf/waterTemp_dailyTot_output.nc'
    ds_3 = nc.Dataset(fn_3)

    # discharge
    fn_4 = '/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_GFDL_SSP3RCP7/'+period+'/'+region+'/netcdf/discharge_dailyTot_output.nc'
    ds_4 = nc.Dataset(fn_4)

  
    shape_store_0 = ds_1['oxygen'].shape[0]
    shape_store_1 = ds_1['oxygen'].shape[1]
    shape_store_2 = ds_1['oxygen'].shape[2]


    ## Update oxygen 
    hybrid_all = np.empty([shape_store_0,shape_store_1,shape_store_2],dtype=float)
  
    for ii in range(0,shape_store_0):      

      OXYGEN = ds_1['oxygen'][ii,:,:]
      BOD = ds_2['BOD_concentration'][ii,:,:]
      WATERTEMP = ds_3['waterTemperature'][ii,:,:]
      DISCHARGE = ds_4['discharge'][ii,:,:]
    
      OXYGEN = np.reshape(OXYGEN, shape_store_1*shape_store_2)
      BOD = np.reshape(BOD, shape_store_1*shape_store_2)
      WATERTEMP = np.reshape(WATERTEMP, shape_store_1*shape_store_2)
      DISCHARGE = np.reshape(DISCHARGE, shape_store_1*shape_store_2)
  
      BOD = np.nan_to_num(BOD)
      WATERTEMP = np.nan_to_num(WATERTEMP)
      DISCHARGE = np.nan_to_num(DISCHARGE)

      # Correct order
      X = np.c_[DISCHARGE,WATERTEMP,BOD]

      predicted = model.predict(X)
      hybrid_oxygen = OXYGEN + predicted
      hybrid_oxygen = np.reshape(hybrid_oxygen,(shape_store_1,shape_store_2))

      hybrid_all[ii,:,:] = hybrid_oxygen
      print(ii)
    
  
    np.save('/gpfs/work4/0/einf6448/HYBRID_GFDL_RUN_JAN_9/'+period+'/'+region+'_do.npy',hybrid_all)


    ## Also store the lat/lon
    fn = '/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_GFDL_SSP3RCP7/'+period+'/'+region+'/netcdf/oxygen_dailyTot_output.nc'
    ds = nc.Dataset(fn)

    lat = ds['lat'][:]
    lon = ds['lon'][:]

    lat = np.array(lat)
    lon = np.array(lon)
    np.save('/gpfs/work4/0/einf6448/HYBRID_GFDL_RUN_JAN_9/'+period+'/'+region+'_lat.npy',lat)
    np.save('/gpfs/work4/0/einf6448/HYBRID_GFDL_RUN_JAN_9/'+period+'/'+region+'_lon.npy',lon)


