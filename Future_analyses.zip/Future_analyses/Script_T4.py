



import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd



## MRI



name_1 = 'discharge'
name_2 = 'discharge'
name_3 = 'discharge'


for period in ['2021-2030','2031-2040','2041-2050','2051-2060','2061-2070','2071-2080','2081-2090','2091-2100']:


  ################################################################################################
  ds_1 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M01/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_2 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M02/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_3 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M03/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_4 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M04/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_5 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M05/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_6 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M06/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_7 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M07/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_8 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M08/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_9 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M09/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_10 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M10/netcdf/' + name_1 + '_dailyTot_output.nc')
  #################################################################################################


  ################################################################################################
  ds_11 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M11/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_12 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M12/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_13 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M13/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_14 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M14/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_15 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M15/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_16 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M16/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_17 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M17/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_18 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M18/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_19 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M19/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_20 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M20/netcdf/' + name_1 + '_dailyTot_output.nc')
  #################################################################################################


  ################################################################################################
  ds_21 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M21/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_22 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M22/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_23 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M23/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_24 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M24/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_25 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M25/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_26 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M26/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_27 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M27/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_30 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M30/netcdf/' + name_1 + '_dailyTot_output.nc')
  #################################################################################################


  ################################################################################################
  ds_31 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M31/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_32 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M32/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_33 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M33/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_34 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M34/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_35 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M35/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_36 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M36/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_37 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M37/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_38 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M38/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_39 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M39/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_40 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M40/netcdf/' + name_1 + '_dailyTot_output.nc')
  #################################################################################################


  ################################################################################################
  ds_41 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M41/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_42 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M42/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_43 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M43/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_44 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M44/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_45 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M45/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_46 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M46/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_47 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M47/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_48 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M48/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_49 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M49/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_50 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M50/netcdf/' + name_1 + '_dailyTot_output.nc')
  #################################################################################################


  ################################################################################################
  ds_51 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M51/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_52 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M52/netcdf/' + name_1 + '_dailyTot_output.nc')

  ds_53 = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M53/netcdf/' + name_1 + '_dailyTot_output.nc')
  #################################################################################################









  # Could have used any of the 53
  time_len = ds_1[name_2].shape[0]









  global_all = []

  for ii in range(0,time_len):

    values = pd.DataFrame()

    tmp = ds_1[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])

    tmp = ds_2[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_3[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_4[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_5[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_6[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_7[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_8[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_9[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_10[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_11[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_12[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_13[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_14[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_15[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_16[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_17[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_18[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_19[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_20[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_21[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_22[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_23[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_24[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_25[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_26[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_27[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_30[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_31[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_32[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_33[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_34[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_35[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_36[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_37[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_38[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_39[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_40[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_41[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_42[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_43[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_44[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_45[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_46[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_47[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_48[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_49[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_50[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_51[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_52[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_53[name_2][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    #print([values.min()[0],values.max()[0]])

    global_value = values.mean()
    global_value = global_value.iloc[0]
    global_all.append(global_value)
    
    print(ii)
  
  
  global_all = pd.DataFrame(global_all)
  global_all = global_all.reset_index(drop=True)
  global_all.to_csv('/gpfs/work4/0/einf6448/Time-Series/avg_' + name_3 + '_' + period + '_MRI.csv',index=False)













  
  
  
  
  