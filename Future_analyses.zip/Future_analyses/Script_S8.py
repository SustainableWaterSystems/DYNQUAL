

import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np
import cartopy.crs as ccrs
from pylab import *
import matplotlib.pylab as pl
import matplotlib.gridspec as gridspec
from scipy import ndimage
from datetime import datetime, timedelta
import matplotlib.dates as mdates
import pymannkendall as mk
import pandas as pd
import cartopy








do_series_all = pd.DataFrame()

for GCM in ['GFDL','IPSL','MPI','MRI','UKESM']:

  do_series_1 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/stress_2021-2030_' + GCM + '.csv')
  do_series_1 = do_series_1.mean()
  do_series_2 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/stress_2031-2040_' + GCM + '.csv')
  do_series_2 = do_series_2.mean()
  do_series_3 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/stress_2041-2050_' + GCM + '.csv')
  do_series_3 = do_series_3.mean()
  do_series_4 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/stress_2051-2060_' + GCM + '.csv')
  do_series_4 = do_series_4.mean()
  do_series_5 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/stress_2061-2070_' + GCM + '.csv')
  do_series_5 = do_series_5.mean()
  do_series_6 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/stress_2071-2080_' + GCM + '.csv')
  do_series_6 = do_series_6.mean()
  do_series_7 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/stress_2081-2090_' + GCM + '.csv')
  do_series_7 = do_series_7.mean()
  do_series_8 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/stress_2091-2100_' + GCM + '.csv')
  do_series_8 = do_series_8.mean()

  do_series = pd.concat([do_series_1,do_series_2,do_series_3,do_series_4,do_series_5,do_series_6,do_series_7,do_series_8])
  do_series = do_series.reset_index(drop=True)
  
  do_series_all = pd.concat([do_series_all,do_series],axis=1)
  




value_all = pd.DataFrame()
for ii in range(0,len(do_series_all)-1):
  value = pd.DataFrame(do_series_all.iloc[ii+1,:]).T.reset_index(drop=True) - pd.DataFrame(do_series_all.iloc[ii,:]).T.reset_index(drop=True)
  value_all = pd.concat([value_all,value])
  
  
do_series_mean_1 = pd.DataFrame(value_all.mean(axis=0))




print('Stress to 2100: 5 GCMs')
print(do_series_mean_1)
print('Average')
print(do_series_mean_1.mean())
print('Standard deviation')
print(do_series_mean_1.std())






do_series_all = pd.DataFrame()

for GCM in ['GFDL','IPSL','MPI','MRI','UKESM']:

  do_series_1 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/hypoxia_2021-2030_' + GCM + '.csv')
  do_series_1 = do_series_1.mean()
  do_series_2 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/hypoxia_2031-2040_' + GCM + '.csv')
  do_series_2 = do_series_2.mean()
  do_series_3 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/hypoxia_2041-2050_' + GCM + '.csv')
  do_series_3 = do_series_3.mean()
  do_series_4 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/hypoxia_2051-2060_' + GCM + '.csv')
  do_series_4 = do_series_4.mean()
  do_series_5 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/hypoxia_2061-2070_' + GCM + '.csv')
  do_series_5 = do_series_5.mean()
  do_series_6 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/hypoxia_2071-2080_' + GCM + '.csv')
  do_series_6 = do_series_6.mean()
  do_series_7 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/hypoxia_2081-2090_' + GCM + '.csv')
  do_series_7 = do_series_7.mean()
  do_series_8 = pd.read_csv('/gpfs/work4/0/einf6448/Time-Series/hypoxia_2091-2100_' + GCM + '.csv')
  do_series_8 = do_series_8.mean()

  do_series = pd.concat([do_series_1,do_series_2,do_series_3,do_series_4,do_series_5,do_series_6,do_series_7,do_series_8])
  do_series = do_series.reset_index(drop=True)
  
  do_series_all = pd.concat([do_series_all,do_series],axis=1)
  
value_all = pd.DataFrame()
for ii in range(0,len(do_series_all)-1):
  value = pd.DataFrame(do_series_all.iloc[ii+1,:]).T.reset_index(drop=True) - pd.DataFrame(do_series_all.iloc[ii,:]).T.reset_index(drop=True)
  value_all = pd.concat([value_all,value])
  
do_series_mean_2 = pd.DataFrame(value_all.mean(axis=0))


print('Hypoxia to 2100: 5 GCMs')
print(do_series_mean_2)
print('Average')
print(do_series_mean_2.mean())
print('Standard deviation')
print(do_series_mean_2.std())

  
  
  

  
  
  








  