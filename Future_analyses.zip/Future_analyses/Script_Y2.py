
import pandas as pd
import numpy as np 
from matplotlib import pyplot as plt
from numpy import hstack
import netCDF4 as nc
import cartopy.crs as ccrs
from pylab import *
import xarray



SR = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/Locations_with_SR.csv',sep=';')
SR = SR.sort_values(by=['INDEX'])
SR = SR.reset_index(drop=True)
print(SR)



for ii in ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
  '22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
  '46','47','48','49','50','51','52','53']:

  data = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_GFDL_June_19/2005-2014/M' + ii + '_DO.nc')
  oxygen = data['Hybrid_DO'][0,:,:]
  
  lon = data['lon'][:]
  lat = data['lat'][:]

  SR_region = SR.loc[SR['Region'] == int(ii)]
  SR_region = SR_region['RASTERVALU']
  SR_region = SR_region.to_numpy()
  SR_region = np.reshape(SR_region,[oxygen.shape[0],oxygen.shape[1]])   
  
  data = xarray.DataArray(SR_region, coords=[('lat', lat), ('lon', lon)], name='SR')
  data.to_netcdf('/gpfs/work4/0/einf6448/Fish_analysis/M' + ii + '_SR.nc')
  print(ii)








