

import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np
import cartopy.crs as ccrs
from pylab import *
import matplotlib.pylab as pl
import matplotlib.gridspec as gridspec
import pandas as pd


output_5 = pd.DataFrame()
output_5_raw = pd.DataFrame()

for GCM in ['Post_Processed_Hybrid_DO_GFDL_June_19','Post_Processed_Hybrid_DO_IPSL_June_19','Post_Processed_Hybrid_DO_MPI_June_19','Post_Processed_Hybrid_DO_MRI_June_19','Post_Processed_Hybrid_DO_UKESM_June_19']:

  output_all = pd.DataFrame()
  output_all_raw = pd.DataFrame()

  for ii in ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
  '22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
  '46','47','48','49','50','51','52','53']:

    oxygen_dec1 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2021-2030/M' + ii + '_DO.nc')
    oxygen_dec1 = oxygen_dec1['Hybrid_DO'][:,:,:]
    mask_1 = np.nanmean(oxygen_dec1,axis=0)
    oxygen_dec1[(oxygen_dec1>=0) & (oxygen_dec1<5)] = 1
    oxygen_dec1[oxygen_dec1>=5] = 0
    oxygen_dec1[oxygen_dec1<0] = 0
    oxygen_dec1 = np.nansum(oxygen_dec1[:,:,:],axis=0)  
  
    oxygen_dec2 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2031-2040/M' + ii + '_DO.nc')
    oxygen_dec2 = oxygen_dec2['Hybrid_DO'][:,:,:]
    mask_2 = np.nanmean(oxygen_dec2,axis=0)
    oxygen_dec2[(oxygen_dec2>=0) & (oxygen_dec2<5)] = 1
    oxygen_dec2[oxygen_dec2>=5] = 0
    oxygen_dec2[oxygen_dec2<0] = 0
    oxygen_dec2 = np.nansum(oxygen_dec2[:,:,:],axis=0)  
    
    oxygen_dec3 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2041-2050/M' + ii + '_DO.nc')
    oxygen_dec3 = oxygen_dec3['Hybrid_DO'][:,:,:]
    mask_3 = np.nanmean(oxygen_dec3,axis=0)
    oxygen_dec3[(oxygen_dec3>=0) & (oxygen_dec3<5)] = 1
    oxygen_dec3[oxygen_dec3>=5] = 0
    oxygen_dec3[oxygen_dec3<0] = 0
    oxygen_dec3 = np.nansum(oxygen_dec3[:,:,:],axis=0) 
    
    oxygen_dec4 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2051-2060/M' + ii + '_DO.nc')
    oxygen_dec4 = oxygen_dec4['Hybrid_DO'][:,:,:]
    mask_4 = np.nanmean(oxygen_dec4,axis=0)
    oxygen_dec4[(oxygen_dec4>=0) & (oxygen_dec4<5)] = 1
    oxygen_dec4[oxygen_dec4>=5] = 0
    oxygen_dec4[oxygen_dec4<0] = 0
    oxygen_dec4 = np.nansum(oxygen_dec4[:,:,:],axis=0) 
    
    oxygen_dec5 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2061-2070/M' + ii + '_DO.nc')
    oxygen_dec5 = oxygen_dec5['Hybrid_DO'][:,:,:]
    mask_5 = np.nanmean(oxygen_dec5,axis=0)
    oxygen_dec5[(oxygen_dec5>=0) & (oxygen_dec5<5)] = 1
    oxygen_dec5[oxygen_dec5>=5] = 0
    oxygen_dec5[oxygen_dec5<0] = 0
    oxygen_dec5 = np.nansum(oxygen_dec5[:,:,:],axis=0) 
    
    oxygen_dec6 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2071-2080/M' + ii + '_DO.nc')
    oxygen_dec6 = oxygen_dec6['Hybrid_DO'][:,:,:]
    mask_6 = np.nanmean(oxygen_dec6,axis=0)
    oxygen_dec6[(oxygen_dec6>=0) & (oxygen_dec6<5)] = 1
    oxygen_dec6[oxygen_dec6>=5] = 0
    oxygen_dec6[oxygen_dec6<0] = 0
    oxygen_dec6 = np.nansum(oxygen_dec6[:,:,:],axis=0) 
    
    oxygen_dec7 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2081-2090/M' + ii + '_DO.nc')
    oxygen_dec7 = oxygen_dec7['Hybrid_DO'][:,:,:]
    mask_7 = np.nanmean(oxygen_dec7,axis=0)
    oxygen_dec7[(oxygen_dec7>=0) & (oxygen_dec7<5)] = 1
    oxygen_dec7[oxygen_dec7>=5] = 0
    oxygen_dec7[oxygen_dec7<0] = 0
    oxygen_dec7 = np.nansum(oxygen_dec7[:,:,:],axis=0) 
    
    oxygen_dec8 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2091-2100/M' + ii + '_DO.nc')
    oxygen_dec8 = oxygen_dec8['Hybrid_DO'][:,:,:]
    mask_8 = np.nanmean(oxygen_dec8,axis=0)
    oxygen_dec8[(oxygen_dec8>=0) & (oxygen_dec8<5)] = 1
    oxygen_dec8[oxygen_dec8>=5] = 0
    oxygen_dec8[oxygen_dec8<0] = 0
    oxygen_dec8 = np.nansum(oxygen_dec8[:,:,:],axis=0) 
    
    ##########################################################################
  
    diff_1 = 100*(oxygen_dec2 - oxygen_dec1)/oxygen_dec1
    diff_2 = 100*(oxygen_dec3 - oxygen_dec2)/oxygen_dec2
    diff_3 = 100*(oxygen_dec4 - oxygen_dec3)/oxygen_dec3
    diff_4 = 100*(oxygen_dec5 - oxygen_dec4)/oxygen_dec4
    diff_5 = 100*(oxygen_dec6 - oxygen_dec5)/oxygen_dec5
    diff_6 = 100*(oxygen_dec7 - oxygen_dec6)/oxygen_dec6
    diff_7 = 100*(oxygen_dec8 - oxygen_dec7)/oxygen_dec7
  
    output = np.nanmean([diff_1,diff_2,diff_3,diff_4,diff_5,diff_6,diff_7], axis=0) 

    
    #########################################################################
    
    diff_1_raw = oxygen_dec2 - oxygen_dec1
    diff_2_raw = oxygen_dec3 - oxygen_dec2
    diff_3_raw = oxygen_dec4 - oxygen_dec3
    diff_4_raw = oxygen_dec5 - oxygen_dec4
    diff_5_raw = oxygen_dec6 - oxygen_dec5
    diff_6_raw = oxygen_dec7 - oxygen_dec6
    diff_7_raw = oxygen_dec8 - oxygen_dec7
  
    output_raw = np.nanmean([diff_1_raw,diff_2_raw,diff_3_raw,diff_4_raw,diff_5_raw,diff_6_raw,diff_7_raw], axis=0) 
    
    
    
    mask_all = np.nanmean([mask_1,mask_2,mask_3,mask_4,mask_5,mask_6,mask_7,mask_8], axis=0) ## Note: This is fine if sure each GCM same pixel coverage.
    output[np.isnan(mask_all)] = np.nan
    output_raw[np.isnan(mask_all)] = np.nan
    
    
    
    output = np.reshape(output,output.shape[0]*output.shape[1])
    output = pd.DataFrame(output)
    output_all = pd.concat([output_all,output])
  
    output_raw = np.reshape(output_raw,output_raw.shape[0]*output_raw.shape[1])
    output_raw = pd.DataFrame(output_raw)
    output_all_raw = pd.concat([output_all_raw,output_raw])

    ##########################################################################
  
  x = output_all.mean()
  output_5 = pd.concat([output_5,x])
  
  x_raw = output_all_raw.mean()
  output_5_raw = pd.concat([output_5_raw,x_raw])


print('Global change in Stress : 5 GCMs')
print(output_5)
print('Average')
print(output_5.mean())
print('Standard deviation')
print(output_5.std())

print('Global change in Stress : 5 GCMs')
print(output_5_raw)
print('Average')
print(output_5_raw.mean())
print('Standard deviation')
print(output_5_raw.std())




  
  

  
  
  
  
  








  