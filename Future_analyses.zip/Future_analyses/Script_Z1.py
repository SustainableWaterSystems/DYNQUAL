

import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np
import cartopy.crs as ccrs
from pylab import *
import matplotlib.pylab as pl
import matplotlib.gridspec as gridspec
from scipy import ndimage
from datetime import datetime, timedelta
import matplotlib.dates as mdates
import pymannkendall as mk
import pandas as pd
import cartopy








do_series_all = pd.DataFrame()

for GCM in ['GFDL','IPSL','MPI','MRI','UKESM']:

  do_series_1 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_2021-2030_' + GCM + '.csv')
  do_series_2 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_2031-2040_' + GCM + '.csv')
  do_series_3 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_2041-2050_' + GCM + '.csv')
  do_series_4 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_2051-2060_' + GCM + '.csv')
  do_series_5 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_2061-2070_' + GCM + '.csv')
  do_series_6 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_2071-2080_' + GCM + '.csv')
  do_series_7 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_2081-2090_' + GCM + '.csv')
  do_series_8 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_2091-2100_' + GCM + '.csv')

  do_series = pd.concat([do_series_1,do_series_2,do_series_3,do_series_4,do_series_5,do_series_6,do_series_7,do_series_8])
  do_series = do_series.reset_index(drop=True)
  
  do_series_all = pd.concat([do_series_all,do_series],axis=1)
  

#print(do_series_all)


x = pd.DataFrame(do_series_all.iloc[0:10957,:]).reset_index(drop=True)
y = pd.DataFrame(do_series_all.iloc[10957:,:]).reset_index(drop=True)
#print(x)
#print(y)

x_5 = pd.DataFrame(x.mean(axis=0))
y_5 = pd.DataFrame(y.mean(axis=0))
#print(x_5)
#print(y_5)



z_5 = 100*(y_5 - x_5)/(x_5)

print('5 GCMs')
print(z_5)
print('Average')
print(z_5.mean())
print('Standard deviation')
print(z_5.std())


## Sensitivity analysis 
#########################################################################################################


do_series_all = pd.DataFrame()

for GCM in ['GFDL','IPSL','MPI','MRI','UKESM']:

  do_series_1 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_SA_2021-2030_' + GCM + '.csv')
  do_series_2 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_SA_2031-2040_' + GCM + '.csv')
  do_series_3 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_SA_2041-2050_' + GCM + '.csv')
  do_series_4 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_SA_2051-2060_' + GCM + '.csv')
  do_series_5 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_SA_2061-2070_' + GCM + '.csv')
  do_series_6 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_SA_2071-2080_' + GCM + '.csv')
  do_series_7 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_SA_2081-2090_' + GCM + '.csv')
  do_series_8 = pd.read_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_SA_2091-2100_' + GCM + '.csv')

  do_series = pd.concat([do_series_1,do_series_2,do_series_3,do_series_4,do_series_5,do_series_6,do_series_7,do_series_8])
  do_series = do_series.reset_index(drop=True)
  
  do_series_all = pd.concat([do_series_all,do_series],axis=1)
  


x = pd.DataFrame(do_series_all.iloc[0:10957,:]).reset_index(drop=True)
y = pd.DataFrame(do_series_all.iloc[10957:,:]).reset_index(drop=True)
#print(x)
#print(y)


x_5 = pd.DataFrame(x.mean(axis=0))
y_5 = pd.DataFrame(y.mean(axis=0))
#print(x_5)
#print(y_5)


z_5 = 100*(y_5 - x_5)/(x_5)

print('5 GCMs: Sensitivity analysis')
print(z_5)
print('Average')
print(z_5.mean())
print('Standard deviation')
print(z_5.std())



  
  
  

  
  
  








  








  