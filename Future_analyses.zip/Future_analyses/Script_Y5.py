




import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd



## MPI




for period in ['2005-2014','2015-2020','2021-2030','2031-2040','2041-2050','2051-2060','2061-2070','2071-2080','2081-2090','2091-2100']:


  ################################################################################################
  ds_1_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M01_DO.nc',mode='r')
  SR_1 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M01_SR.nc')
  SR_1 = SR_1['SR'][:,:]

  ds_2_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M02_DO.nc',mode='r')
  SR_2 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M02_SR.nc')
  SR_2 = SR_2['SR'][:,:]

  ds_3_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M03_DO.nc',mode='r')
  SR_3 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M03_SR.nc')
  SR_3 = SR_3['SR'][:,:]

  ds_4_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M04_DO.nc',mode='r')
  SR_4 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M04_SR.nc')
  SR_4 = SR_4['SR'][:,:]

  ds_5_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M05_DO.nc',mode='r')
  SR_5 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M05_SR.nc')
  SR_5 = SR_5['SR'][:,:]

  ds_6_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M06_DO.nc',mode='r')
  SR_6 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M06_SR.nc')
  SR_6 = SR_6['SR'][:,:]

  ds_7_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M07_DO.nc',mode='r')
  SR_7 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M07_SR.nc')
  SR_7 = SR_7['SR'][:,:]

  ds_8_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M08_DO.nc',mode='r')
  SR_8 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M08_SR.nc')
  SR_8 = SR_8['SR'][:,:]

  ds_9_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M09_DO.nc',mode='r')
  SR_9 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M09_SR.nc')
  SR_9 = SR_9['SR'][:,:]

  ds_10_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M10_DO.nc',mode='r')
  SR_10 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M10_SR.nc')
  SR_10 = SR_10['SR'][:,:]
  #################################################################################################


  ################################################################################################
  ds_11_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M11_DO.nc',mode='r')
  SR_11 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M11_SR.nc')
  SR_11 = SR_11['SR'][:,:]

  ds_12_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M12_DO.nc',mode='r')
  SR_12 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M12_SR.nc')
  SR_12 = SR_12['SR'][:,:]

  ds_13_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M13_DO.nc',mode='r')
  SR_13 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M13_SR.nc')
  SR_13 = SR_13['SR'][:,:]

  ds_14_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M14_DO.nc',mode='r')
  SR_14 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M14_SR.nc')
  SR_14 = SR_14['SR'][:,:]

  ds_15_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M15_DO.nc',mode='r')
  SR_15 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M15_SR.nc')
  SR_15 = SR_15['SR'][:,:]

  ds_16_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M16_DO.nc',mode='r')
  SR_16 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M16_SR.nc')
  SR_16 = SR_16['SR'][:,:]

  ds_17_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M17_DO.nc',mode='r')
  SR_17 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M17_SR.nc')
  SR_17 = SR_17['SR'][:,:]

  ds_18_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M18_DO.nc',mode='r')
  SR_18 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M18_SR.nc')
  SR_18 = SR_18['SR'][:,:]

  ds_19_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M19_DO.nc',mode='r')
  SR_19 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M19_SR.nc')
  SR_19 = SR_19['SR'][:,:]
  
  ds_20_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M20_DO.nc',mode='r')
  SR_20 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M20_SR.nc')
  SR_20 = SR_20['SR'][:,:]
  #################################################################################################


  ################################################################################################
  ds_21_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M21_DO.nc',mode='r')
  SR_21 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M21_SR.nc')
  SR_21 = SR_21['SR'][:,:]

  ds_22_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M22_DO.nc',mode='r')
  SR_22 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M22_SR.nc')
  SR_22 = SR_22['SR'][:,:]

  ds_23_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M23_DO.nc',mode='r')
  SR_23 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M23_SR.nc')
  SR_23 = SR_23['SR'][:,:]

  ds_24_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M24_DO.nc',mode='r')
  SR_24 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M24_SR.nc')
  SR_24 = SR_24['SR'][:,:]

  ds_25_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M25_DO.nc',mode='r')
  SR_25 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M25_SR.nc')
  SR_25 = SR_25['SR'][:,:]

  ds_26_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M26_DO.nc',mode='r')
  SR_26 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M26_SR.nc')
  SR_26 = SR_26['SR'][:,:]

  ds_27_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M27_DO.nc',mode='r')
  SR_27 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M27_SR.nc')
  SR_27 = SR_27['SR'][:,:]

  ds_30_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M30_DO.nc',mode='r')
  SR_30 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M30_SR.nc')
  SR_30 = SR_30['SR'][:,:]
  #################################################################################################


  ################################################################################################
  ds_31_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M31_DO.nc',mode='r')
  SR_31 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M31_SR.nc')
  SR_31 = SR_31['SR'][:,:]

  ds_32_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M32_DO.nc',mode='r')
  SR_32 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M32_SR.nc')
  SR_32 = SR_32['SR'][:,:]

  ds_33_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M33_DO.nc',mode='r')
  SR_33 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M33_SR.nc')
  SR_33 = SR_33['SR'][:,:]

  ds_34_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M34_DO.nc',mode='r')
  SR_34 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M34_SR.nc')
  SR_34 = SR_34['SR'][:,:]

  ds_35_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M35_DO.nc',mode='r')
  SR_35 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M35_SR.nc')
  SR_35 = SR_35['SR'][:,:]

  ds_36_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M36_DO.nc',mode='r')
  SR_36 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M36_SR.nc')
  SR_36 = SR_36['SR'][:,:]

  ds_37_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M37_DO.nc',mode='r')
  SR_37 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M37_SR.nc')
  SR_37 = SR_37['SR'][:,:]

  ds_38_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M38_DO.nc',mode='r')
  SR_38 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M38_SR.nc')
  SR_38 = SR_38['SR'][:,:]

  ds_39_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M39_DO.nc',mode='r')
  SR_39 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M39_SR.nc')
  SR_39 = SR_39['SR'][:,:]

  ds_40_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M40_DO.nc',mode='r')
  SR_40 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M40_SR.nc')
  SR_40 = SR_40['SR'][:,:]
  #################################################################################################


  ################################################################################################
  ds_41_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M41_DO.nc',mode='r')
  SR_41 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M41_SR.nc')
  SR_41 = SR_41['SR'][:,:]

  ds_42_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M42_DO.nc',mode='r')
  SR_42 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M42_SR.nc')
  SR_42 = SR_42['SR'][:,:]

  ds_43_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M43_DO.nc',mode='r')
  SR_43 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M43_SR.nc')
  SR_43 = SR_43['SR'][:,:]

  ds_44_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M44_DO.nc',mode='r')
  SR_44 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M44_SR.nc')
  SR_44 = SR_44['SR'][:,:]

  ds_45_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M45_DO.nc',mode='r')
  SR_45 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M45_SR.nc')
  SR_45 = SR_45['SR'][:,:]

  ds_46_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M46_DO.nc',mode='r')
  SR_46 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M46_SR.nc')
  SR_46 = SR_46['SR'][:,:]

  ds_47_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M47_DO.nc',mode='r')
  SR_47 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M47_SR.nc')
  SR_47 = SR_47['SR'][:,:]

  ds_48_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M48_DO.nc',mode='r')
  SR_48 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M48_SR.nc')
  SR_48 = SR_48['SR'][:,:]

  ds_49_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M49_DO.nc',mode='r')
  SR_49 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M49_SR.nc')
  SR_49 = SR_49['SR'][:,:]

  ds_50_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M50_DO.nc',mode='r')
  SR_50 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M50_SR.nc')
  SR_50 = SR_50['SR'][:,:]
  #################################################################################################


  ################################################################################################
  ds_51_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M51_DO.nc',mode='r')
  SR_51 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M51_SR.nc')
  SR_51 = SR_51['SR'][:,:]

  ds_52_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M52_DO.nc',mode='r')
  SR_52 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M52_SR.nc')
  SR_52 = SR_52['SR'][:,:]

  ds_53_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MPI_June_19/' + period + '/M53_DO.nc',mode='r')
  SR_53 = nc.Dataset('/gpfs/work4/0/einf6448/Fish_analysis/M53_SR.nc')
  SR_53 = SR_53['SR'][:,:]
  #################################################################################################









  # Could have used any of the 53
  time_len = ds_1_hyb['Hybrid_DO'].shape[0]











  hypoxia_all = []
  hypoxia_all_SA = []

  for ii in range(0,time_len):

    values = pd.DataFrame()

    tmp = ds_1_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_1,SR_1.shape[0]*SR_1.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])

    tmp = ds_2_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_2,SR_2.shape[0]*SR_2.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_3_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_3,SR_3.shape[0]*SR_3.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_4_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_4,SR_4.shape[0]*SR_4.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_5_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_5,SR_5.shape[0]*SR_5.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_6_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_6,SR_6.shape[0]*SR_6.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_7_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_7,SR_7.shape[0]*SR_7.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_8_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_8,SR_8.shape[0]*SR_8.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_9_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_9,SR_9.shape[0]*SR_9.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_10_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_10,SR_10.shape[0]*SR_10.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_11_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_11,SR_11.shape[0]*SR_11.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_12_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_12,SR_12.shape[0]*SR_12.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_13_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_13,SR_13.shape[0]*SR_13.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_14_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_14,SR_14.shape[0]*SR_14.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_15_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_15,SR_15.shape[0]*SR_15.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_16_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_16,SR_16.shape[0]*SR_16.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_17_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_17,SR_17.shape[0]*SR_17.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_18_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_18,SR_18.shape[0]*SR_18.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_19_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_19,SR_19.shape[0]*SR_19.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_20_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_20,SR_20.shape[0]*SR_20.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_21_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_21,SR_21.shape[0]*SR_21.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_22_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_22,SR_22.shape[0]*SR_22.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_23_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_23,SR_23.shape[0]*SR_23.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_24_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_24,SR_24.shape[0]*SR_24.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_25_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_25,SR_25.shape[0]*SR_25.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_26_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_26,SR_26.shape[0]*SR_26.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_27_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_27,SR_27.shape[0]*SR_27.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_30_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_30,SR_30.shape[0]*SR_30.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_31_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_31,SR_31.shape[0]*SR_31.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_32_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_32,SR_32.shape[0]*SR_32.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_33_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_33,SR_33.shape[0]*SR_33.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_34_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_34,SR_34.shape[0]*SR_34.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_35_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_35,SR_35.shape[0]*SR_35.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_36_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_36,SR_36.shape[0]*SR_36.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_37_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_37,SR_37.shape[0]*SR_37.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_38_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_38,SR_38.shape[0]*SR_38.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_39_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_39,SR_39.shape[0]*SR_39.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_40_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_40,SR_40.shape[0]*SR_40.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_41_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_41,SR_41.shape[0]*SR_41.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_42_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_42,SR_42.shape[0]*SR_42.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_43_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_43,SR_43.shape[0]*SR_43.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_44_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_44,SR_44.shape[0]*SR_44.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_45_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_45,SR_45.shape[0]*SR_45.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_46_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_46,SR_46.shape[0]*SR_46.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_47_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_47,SR_47.shape[0]*SR_47.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_48_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_48,SR_48.shape[0]*SR_48.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_49_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_49,SR_49.shape[0]*SR_49.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])

    tmp = ds_50_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_50,SR_50.shape[0]*SR_50.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_51_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_51,SR_51.shape[0]*SR_51.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_52_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_52,SR_52.shape[0]*SR_52.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_53_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp_SR = np.reshape(SR_53,SR_53.shape[0]*SR_53.shape[1])
    tmp_SR = pd.DataFrame(tmp_SR)
    tmp['SR'] = tmp_SR
    tmp = tmp.loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    #print([values.min()[0],values.max()[0]])
    
    values_Main = values.copy()
    values_SA = values.copy()

    values_Main['Tmp'].loc[(values_Main['Tmp']>=0) & (values_Main['Tmp']<3)] = 1
    values_Main['Tmp'].loc[(values_Main['Tmp'] >= 3)] = 0
    values_Main['Tmp'].loc[(values_Main['Tmp'] < 0)] = 0
    values_Main = values_Main.dropna()
    values_Main['Output'] = values_Main['Tmp'] * values_Main['SR']
    hypoxia_value = values_Main['Output'].mean()
    hypoxia_all.append(hypoxia_value)
    
    values_SA['Tmp'].loc[(values_SA['Tmp']>=0) & (values_SA['Tmp']<2)] = 1
    values_SA['Tmp'].loc[(values_SA['Tmp'] >= 2)] = 0
    values_SA['Tmp'].loc[(values_SA['Tmp'] < 0)] = 0
    values_SA = values_SA.dropna()
    values_SA['Output'] = values_SA['Tmp'] * values_SA['SR']
    hypoxia_value_SA = values_SA['Output'].mean()
    hypoxia_all_SA.append(hypoxia_value_SA)
    
    print(ii)
  

  hypoxia_all = pd.DataFrame(hypoxia_all)
  hypoxia_all = hypoxia_all.reset_index(drop=True)
  hypoxia_all.to_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_' + period + '_MPI.csv',index=False)
  
  hypoxia_all_SA = pd.DataFrame(hypoxia_all_SA)
  hypoxia_all_SA = hypoxia_all_SA.reset_index(drop=True)
  hypoxia_all_SA.to_csv('/gpfs/work4/0/einf6448/Fish_analysis/NSR_SA_' + period + '_MPI.csv',index=False)












  
  
  
  
  