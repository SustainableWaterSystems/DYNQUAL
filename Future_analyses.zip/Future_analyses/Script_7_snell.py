

import pandas as pd
import numpy as np 
from matplotlib import pyplot as plt
from numpy import hstack
import netCDF4 as nc
from pylab import *
import xarray





for period in ['2005-2014','2015-2020','2021-2030','2031-2040','2041-2050','2051-2060','2061-2070','2071-2080','2081-2090','2091-2100']:

  for ii in ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
  '22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
  '46','47','48','49','50','51','52','53']:

    oxygen = np.load('/gpfs/work4/0/einf6448/HYBRID_MRI_RUN_MARCH_24/' + period + '/M' + ii + '_do.npy')
  
    pb = nc.Dataset('/gpfs/work4/0/einf6448/users/dgraham/DynQual_DO_MRI_SSP3RCP7/' + period + '/M' + ii + '/netcdf/oxygen_dailyTot_output.nc')
    time = pb['time'][:]
  
    lat = np.load('/gpfs/work4/0/einf6448/HYBRID_MRI_RUN_MARCH_24/' + period + '/M' + ii + '_lat.npy')
    lon = np.load('/gpfs/work4/0/einf6448/HYBRID_MRI_RUN_MARCH_24/' + period + '/M' + ii + '_lon.npy')

    data = xarray.DataArray(oxygen, coords=[('time', time), ('lat', lat), ('lon', lon)], name='Hybrid_DO')
  
    data.attrs['name'] = 'Dissolved Oxygen (DynQual_Random Forest)'
    data.attrs['units'] = 'mg/l'
    data.time.attrs['name'] = 'time'
    data.time.attrs['units'] = 'days since 1901-01-01'
    data.lat.attrs['name'] = 'latitude'
    data.lat.attrs['units'] = 'degrees_north'
    data.lon.attrs['name'] = 'longitude'
    data.lon.attrs['units'] = 'degrees_east'

    data.to_netcdf('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M' + ii + '_DO.nc')

    print(np.nanmin(np.nanmin(oxygen)))
    print(np.nanmax(np.nanmax(oxygen)))
    print(ii)
  
  


