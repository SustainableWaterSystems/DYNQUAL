


import pandas as pd
import numpy as np 
from matplotlib import pyplot as plt
from numpy import hstack

import netCDF4 as nc
import cartopy.crs as ccrs
from pylab import *



oxygen_all = pd.DataFrame()

for ii in ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
  '22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
  '46','47','48','49','50','51','52','53']:

  data = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_GFDL_June_19/2005-2014/M' + ii + '_DO.nc')
  oxygen = data['Hybrid_DO'][0,:,:]
  
  lon = data['lon'][:]
  lat = data['lat'][:]

  lon = pd.DataFrame(lon)
  lat = pd.DataFrame(lat)
  lon = lon.T
  lon = pd.concat([lon]*oxygen.shape[0])
  lat = pd.concat([lat]*oxygen.shape[1],axis=1)
  lon = np.array(lon)
  lat = np.array(lat)
  
  oxygen = np.reshape(oxygen,oxygen.shape[0]*oxygen.shape[1])
  lon = np.reshape(lon,lon.shape[0]*lon.shape[1])
  lat = np.reshape(lat,lat.shape[0]*lat.shape[1])
  
  oxygen = pd.DataFrame(oxygen,columns=['Oxygen'])
  oxygen['Lon'] = lon
  oxygen['Lat'] = lat

  oxygen['Region'] = ii
  
  oxygen_all = pd.concat([oxygen_all,oxygen])
  print(len(oxygen_all))
  print(ii)

oxygen_all = oxygen_all.reset_index(drop=True)
oxygen_all['INDEX'] = oxygen_all.index
oxygen_all.to_csv('/gpfs/work4/0/einf6448/Fish_analysis/Locations_without_SR.csv',index=False)






