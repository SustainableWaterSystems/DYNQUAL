




import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd



## MRI




for period in ['2005-2014','2015-2020','2021-2030','2031-2040','2041-2050','2051-2060','2061-2070','2071-2080','2081-2090','2091-2100']:


  ################################################################################################
  ds_1_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M01_DO.nc',mode='r')

  ds_2_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M02_DO.nc',mode='r')

  ds_3_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M03_DO.nc',mode='r')

  ds_4_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M04_DO.nc',mode='r')

  ds_5_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M05_DO.nc',mode='r')

  ds_6_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M06_DO.nc',mode='r')

  ds_7_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M07_DO.nc',mode='r')

  ds_8_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M08_DO.nc',mode='r')

  ds_9_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M09_DO.nc',mode='r')

  ds_10_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M10_DO.nc',mode='r')
  #################################################################################################


  ################################################################################################
  ds_11_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M11_DO.nc',mode='r')

  ds_12_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M12_DO.nc',mode='r')

  ds_13_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M13_DO.nc',mode='r')

  ds_14_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M14_DO.nc',mode='r')

  ds_15_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M15_DO.nc',mode='r')

  ds_16_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M16_DO.nc',mode='r')

  ds_17_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M17_DO.nc',mode='r')

  ds_18_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M18_DO.nc',mode='r')

  ds_19_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M19_DO.nc',mode='r')

  ds_20_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M20_DO.nc',mode='r')
  #################################################################################################


  ################################################################################################
  ds_21_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M21_DO.nc',mode='r')

  ds_22_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M22_DO.nc',mode='r')

  ds_23_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M23_DO.nc',mode='r')

  ds_24_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M24_DO.nc',mode='r')

  ds_25_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M25_DO.nc',mode='r')

  ds_26_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M26_DO.nc',mode='r')

  ds_27_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M27_DO.nc',mode='r')

  ds_30_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M30_DO.nc',mode='r')
  #################################################################################################


  ################################################################################################
  ds_31_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M31_DO.nc',mode='r')

  ds_32_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M32_DO.nc',mode='r')

  ds_33_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M33_DO.nc',mode='r')

  ds_34_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M34_DO.nc',mode='r')

  ds_35_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M35_DO.nc',mode='r')

  ds_36_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M36_DO.nc',mode='r')

  ds_37_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M37_DO.nc',mode='r')

  ds_38_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M38_DO.nc',mode='r')

  ds_39_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M39_DO.nc',mode='r')

  ds_40_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M40_DO.nc',mode='r')
  #################################################################################################


  ################################################################################################
  ds_41_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M41_DO.nc',mode='r')

  ds_42_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M42_DO.nc',mode='r')

  ds_43_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M43_DO.nc',mode='r')

  ds_44_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M44_DO.nc',mode='r')

  ds_45_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M45_DO.nc',mode='r')

  ds_46_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M46_DO.nc',mode='r')

  ds_47_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M47_DO.nc',mode='r')

  ds_48_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M48_DO.nc',mode='r')

  ds_49_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M49_DO.nc',mode='r')

  ds_50_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M50_DO.nc',mode='r')
  #################################################################################################


  ################################################################################################
  ds_51_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M51_DO.nc',mode='r')

  ds_52_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M52_DO.nc',mode='r')

  ds_53_hyb = nc.Dataset('/gpfs/work4/0/einf6448/Post_Processed_Hybrid_DO_MRI_June_19/' + period + '/M53_DO.nc',mode='r')
  #################################################################################################









  # Could have used any of the 53
  time_len = ds_1_hyb['Hybrid_DO'].shape[0]









  global_all = []
  stress_all = []
  hypoxia_all = []

  for ii in range(0,time_len):

    values = pd.DataFrame()

    tmp = ds_1_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])

    tmp = ds_2_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_3_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_4_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_5_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_6_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_7_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_8_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_9_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_10_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_11_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_12_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_13_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_14_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_15_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_16_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_17_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_18_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_19_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_20_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_21_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_22_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_23_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_24_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_25_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_26_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_27_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_30_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_31_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_32_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_33_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_34_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_35_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_36_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_37_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_38_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_39_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_40_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_41_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_42_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_43_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_44_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_45_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_46_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_47_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_48_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_49_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])

    tmp = ds_50_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_51_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_52_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    tmp = ds_53_hyb['Hybrid_DO'][ii,:,:]
    tmp = np.reshape(tmp,tmp.shape[0]*tmp.shape[1])
    tmp = pd.DataFrame(tmp,columns=['Tmp'])
    tmp = tmp['Tmp'].loc[~np.isnan(tmp['Tmp'])]
    values = pd.concat([values,tmp])
  
    #print([values.min()[0],values.max()[0]])

    global_value = values.mean()
    global_value = global_value.iloc[0]
    global_all.append(global_value)
    
    stress_value = len(values[(values>=0) & (values<5)].dropna())
    stress_all.append(stress_value)
    
    hypoxia_value = len(values[(values>=0) & (values<3)].dropna())
    hypoxia_all.append(hypoxia_value)
    
    print(ii)
  
  
  global_all = pd.DataFrame(global_all)
  global_all = global_all.reset_index(drop=True)
  global_all.to_csv('/gpfs/work4/0/einf6448/Time-Series/avg_oxy_' + period + '_MRI.csv',index=False)

  stress_all = pd.DataFrame(stress_all)
  stress_all = stress_all.reset_index(drop=True)
  stress_all.to_csv('/gpfs/work4/0/einf6448/Time-Series/stress_' + period + '_MRI.csv',index=False)

  hypoxia_all = pd.DataFrame(hypoxia_all)
  hypoxia_all = hypoxia_all.reset_index(drop=True)
  hypoxia_all.to_csv('/gpfs/work4/0/einf6448/Time-Series/hypoxia_' + period + '_MRI.csv',index=False)
  












  
  
  
  
  