

import netCDF4 as nc
import matplotlib.pyplot as plt
import numpy as np
import cartopy.crs as ccrs
from pylab import *
import matplotlib.pylab as pl
import matplotlib.gridspec as gridspec
import pandas as pd


output_5_1 = pd.DataFrame()
output_5_2 = pd.DataFrame()

for GCM in ['Post_Processed_Hybrid_DO_GFDL_June_19','Post_Processed_Hybrid_DO_IPSL_June_19','Post_Processed_Hybrid_DO_MPI_June_19','Post_Processed_Hybrid_DO_MRI_June_19','Post_Processed_Hybrid_DO_UKESM_June_19']:

  output_all_1 = pd.DataFrame()
  output_all_2 = pd.DataFrame()

  for ii in ['01','02','03','04','05','06','07','08','09','10','11','12','13','14','15','16','17','18','19','20','21',
  '22','23','24','25','26','27','30','31','32','33','34','35','36','37','38','39','40','41','42','43','44','45',
  '46','47','48','49','50','51','52','53']:

    oxygen_dec1 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2021-2030/M' + ii + '_DO.nc')
    oxygen_dec1 = np.nanmean(oxygen_dec1['Hybrid_DO'][:,:,:],axis=0) 
  
    oxygen_dec2 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2031-2040/M' + ii + '_DO.nc')
    oxygen_dec2 = np.nanmean(oxygen_dec2['Hybrid_DO'][:,:,:],axis=0) 
    
    oxygen_dec3 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2041-2050/M' + ii + '_DO.nc')
    oxygen_dec3 = np.nanmean(oxygen_dec3['Hybrid_DO'][:,:,:],axis=0) 
    
    oxygen_dec4 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2051-2060/M' + ii + '_DO.nc')
    oxygen_dec4 = np.nanmean(oxygen_dec4['Hybrid_DO'][:,:,:],axis=0)  
    
    oxygen_dec5 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2061-2070/M' + ii + '_DO.nc')
    oxygen_dec5 = np.nanmean(oxygen_dec5['Hybrid_DO'][:,:,:],axis=0)  
    
    oxygen_dec6 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2071-2080/M' + ii + '_DO.nc')
    oxygen_dec6 = np.nanmean(oxygen_dec6['Hybrid_DO'][:,:,:],axis=0) 
    
    oxygen_dec7 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2081-2090/M' + ii + '_DO.nc')
    oxygen_dec7 = np.nanmean(oxygen_dec7['Hybrid_DO'][:,:,:],axis=0) 
    
    oxygen_dec8 = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2091-2100/M' + ii + '_DO.nc')
    oxygen_dec8 = np.nanmean(oxygen_dec8['Hybrid_DO'][:,:,:],axis=0) 
    
    diff_1 = oxygen_dec2 - oxygen_dec1
    diff_2 = oxygen_dec3 - oxygen_dec2
    diff_3 = oxygen_dec4 - oxygen_dec3
    diff_4 = oxygen_dec5 - oxygen_dec4
    diff_5 = oxygen_dec6 - oxygen_dec5
    diff_6 = oxygen_dec7 - oxygen_dec6
    diff_7 = oxygen_dec8 - oxygen_dec7
  
    output = np.nanmean([diff_1,diff_2,diff_3,diff_4,diff_5,diff_6,diff_7], axis=0) 
  
    tmp = nc.Dataset('/gpfs/work4/0/einf6448/' + GCM + '/2091-2100/M' + ii + '_DO.nc')
    lon = tmp['lon'][:]
    lat = tmp['lat'][:]
  
    lon = pd.DataFrame(lon)
    lon = lon.T
    lon = pd.concat([lon]*output.shape[0],axis=0)
    lat = pd.DataFrame(lat)
    lat = pd.concat([lat]*output.shape[1],axis=1)
  
    output = np.reshape(output,output.shape[0]*output.shape[1])
    lon = np.reshape(lon,lon.shape[0]*lon.shape[1])
    lat = np.reshape(lat,lat.shape[0]*lat.shape[1])
  
    output = pd.DataFrame(output)
  
    output_northTemp = output.loc[(lat > 23.5) & (lat < 66.5)]  
    output_southTemp = output.loc[(lat < -23.5) & (lat > -66.5)]               
    output_northTemp = output_northTemp.dropna() 
    output_southTemp = output_southTemp.dropna()
    output_all_1 = pd.concat([output_all_1, output_northTemp, output_southTemp])
  
    output_2 = output.loc[(lat < 23.5) & (lat > -23.5)]
    output_2 = output_2.dropna()
    output_all_2 = pd.concat([output_all_2,output_2])

  x = output_all_1.mean()
  y = output_all_2.mean()

  output_5_1 = pd.concat([output_5_1,x])
  output_5_2 = pd.concat([output_5_2,y])


print('Change in mean DO (Temperate region!) 5 GCMs')
print(output_5_1)
print('Average')
print(output_5_1.mean())
print('Standard deviation')
print(output_5_1.std())

print('Change in mean DO (Tropical region!) 5 GCMs')
print(output_5_2)
print('Average')
print(output_5_2.mean())
print('Standard deviation')
print(output_5_2.std())



